import { pgTable, text, serial, integer, decimal, timestamp, boolean, json, doublePrecision } from "drizzle-orm/pg-core";
import { createInsertSchema } from "drizzle-zod";
import { z } from "zod";

export const users = pgTable("users", {
  id: serial("id").primaryKey(),
  username: text("username").notNull().unique(),
  email: text("email").notNull().unique(),
  subscriptionTier: text("subscription_tier").notNull().default("basic"),
  createdAt: timestamp("created_at").notNull().defaultNow(),
});

export const wearableData = pgTable("wearable_data", {
  id: serial("id").primaryKey(),
  userId: integer("user_id").notNull(),
  deviceType: text("device_type").notNull(), // 'whoop', 'apple_watch'
  sleepScore: integer("sleep_score"),
  sleepDuration: text("sleep_duration"),
  strainLevel: decimal("strain_level", { precision: 5, scale: 3 }),
  hrv: decimal("hrv", { precision: 5, scale: 3 }),
  heartRate: integer("heart_rate"),
  recordedAt: timestamp("recorded_at").notNull().defaultNow(),
});

export const mealPlans = pgTable("meal_plans", {
  id: serial("id").primaryKey(),
  userId: integer("user_id").notNull(),
  mealType: text("meal_type").notNull(), // 'breakfast', 'lunch', 'dinner'
  name: text("name").notNull(),
  description: text("description"),
  calories: integer("calories"),
  protein: integer("protein"),
  carbs: integer("carbs"),
  fat: integer("fat"),
  imageUrl: text("image_url"),
  createdAt: timestamp("created_at").notNull().defaultNow(),
});

export const recoveryProtocols = pgTable("recovery_protocols", {
  id: serial("id").primaryKey(),
  userId: integer("user_id").notNull(),
  type: text("type").notNull(), // 'cold_therapy', 'breathwork', 'supplements'
  name: text("name").notNull(),
  description: text("description"),
  duration: text("duration"),
  createdAt: timestamp("created_at").notNull().defaultNow(),
});

export const performanceScores = pgTable("performance_scores", {
  id: serial("id").primaryKey(),
  userId: integer("user_id").notNull(),
  sleepScore: integer("sleep_score"),
  recoveryScore: integer("recovery_score"),
  strainLevel: decimal("strain_level", { precision: 3, scale: 1 }),
  overallScore: integer("overall_score"),
  date: timestamp("date").notNull().defaultNow(),
});

export const wearableTokens = pgTable("wearable_tokens", {
  id: serial("id").primaryKey(),
  userId: integer("user_id").notNull(),
  provider: text("provider").notNull(), // 'whoop' or 'apple_health'
  accessToken: text("access_token").notNull(),
  refreshToken: text("refresh_token"),
  externalUserId: text("external_user_id"), // Terra user ID for Apple Health
  expiresAt: timestamp("expires_at"),
  createdAt: timestamp("created_at").notNull().defaultNow(),
  updatedAt: timestamp("updated_at").notNull().defaultNow(),
});

export const coachingSessions = pgTable("coaching_sessions", {
  id: serial("id").primaryKey(),
  userId: integer("user_id").notNull(),
  personalizedMessage: text("personalized_message").notNull(),
  keyInsights: text("key_insights").array().notNull(),
  weeklyFocus: text("weekly_focus").notNull(),
  motivationalNote: text("motivational_note").notNull(),
  nextCheckIn: text("next_check_in").notNull(),
  performanceTrend: doublePrecision("performance_trend").default(0),
  createdAt: timestamp("created_at").notNull().defaultNow(),
});

export const coachingRecommendations = pgTable("coaching_recommendations", {
  id: serial("id").primaryKey(),
  sessionId: integer("session_id").notNull(),
  priority: text("priority").notNull(), // 'high', 'medium', 'low'
  category: text("category").notNull(), // 'sleep', 'recovery', 'nutrition', 'training', 'stress'
  title: text("title").notNull(),
  description: text("description").notNull(),
  timeframe: text("timeframe").notNull(),
  completed: boolean("completed").default(false),
  createdAt: timestamp("created_at").notNull().defaultNow(),
});

export const userPreferences = pgTable("user_preferences", {
  id: serial("id").primaryKey(),
  userId: integer("user_id").notNull(),
  goals: text("goals").array().default([]),
  currentChallenges: text("current_challenges").array().default([]),
  workoutTypes: text("workout_types").array().default([]),
  dietaryRestrictions: text("dietary_restrictions").array().default([]),
  sleepSchedule: text("sleep_schedule"),
  updatedAt: timestamp("updated_at").notNull().defaultNow(),
});

// Schema validations
export const insertUserSchema = createInsertSchema(users).pick({
  username: true,
  email: true,
  subscriptionTier: true,
});

export const insertWearableDataSchema = createInsertSchema(wearableData).pick({
  userId: true,
  deviceType: true,
  sleepScore: true,
  sleepDuration: true,
  strainLevel: true,
  hrv: true,
  heartRate: true,
});

export const insertMealPlanSchema = createInsertSchema(mealPlans).pick({
  userId: true,
  mealType: true,
  name: true,
  description: true,
  calories: true,
  protein: true,
  carbs: true,
  fat: true,
  imageUrl: true,
});

export const insertRecoveryProtocolSchema = createInsertSchema(recoveryProtocols).pick({
  userId: true,
  type: true,
  name: true,
  description: true,
  duration: true,
});

export const insertPerformanceScoreSchema = createInsertSchema(performanceScores).pick({
  userId: true,
  sleepScore: true,
  recoveryScore: true,
  strainLevel: true,
  overallScore: true,
});

export const insertWearableTokenSchema = createInsertSchema(wearableTokens).pick({
  userId: true,
  provider: true,
  accessToken: true,
  refreshToken: true,
  externalUserId: true,
  expiresAt: true,
});

export const insertCoachingSessionSchema = createInsertSchema(coachingSessions).pick({
  userId: true,
  personalizedMessage: true,
  keyInsights: true,
  weeklyFocus: true,
  motivationalNote: true,
  nextCheckIn: true,
  performanceTrend: true,
});

export const insertCoachingRecommendationSchema = createInsertSchema(coachingRecommendations).pick({
  sessionId: true,
  priority: true,
  category: true,
  title: true,
  description: true,
  timeframe: true,
});

export const insertUserPreferencesSchema = createInsertSchema(userPreferences).pick({
  userId: true,
  goals: true,
  currentChallenges: true,
  workoutTypes: true,
  dietaryRestrictions: true,
  sleepSchedule: true,
});

// Types
export type User = typeof users.$inferSelect;
export type InsertUser = z.infer<typeof insertUserSchema>;
export type WearableData = typeof wearableData.$inferSelect;
export type InsertWearableData = z.infer<typeof insertWearableDataSchema>;
export type MealPlan = typeof mealPlans.$inferSelect;
export type InsertMealPlan = z.infer<typeof insertMealPlanSchema>;
export type RecoveryProtocol = typeof recoveryProtocols.$inferSelect;
export type InsertRecoveryProtocol = z.infer<typeof insertRecoveryProtocolSchema>;
export type PerformanceScore = typeof performanceScores.$inferSelect;
export type InsertPerformanceScore = z.infer<typeof insertPerformanceScoreSchema>;
export type WearableToken = typeof wearableTokens.$inferSelect;
export type InsertWearableToken = z.infer<typeof insertWearableTokenSchema>;
export type CoachingSession = typeof coachingSessions.$inferSelect;
export type InsertCoachingSession = z.infer<typeof insertCoachingSessionSchema>;
export type CoachingRecommendation = typeof coachingRecommendations.$inferSelect;
export type InsertCoachingRecommendation = z.infer<typeof insertCoachingRecommendationSchema>;
export type UserPreferences = typeof userPreferences.$inferSelect;
export type InsertUserPreferences = z.infer<typeof insertUserPreferencesSchema>;
