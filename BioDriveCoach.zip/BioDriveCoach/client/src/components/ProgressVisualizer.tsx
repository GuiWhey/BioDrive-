import { Card, CardContent } from "@/components/ui/card";
import { LineChart, Line, XAxis, YAxis, CartesianGrid, Tooltip, ResponsiveContainer } from "recharts";
import { TrendingUp, Heart } from "lucide-react";

interface ProgressVisualizerProps {
  performanceScores: Array<{
    id: number;
    sleepScore: number;
    recoveryScore: number;
    strainLevel: string;
    overallScore: number;
    date: string;
  }>;
  wearableData?: {
    sleepScore: number;
    strainLevel: string;
    hrv: number;
  };
}

export default function ProgressVisualizer({ performanceScores, wearableData }: ProgressVisualizerProps) {
  // Generate mock data for the chart if no real data
  const mockData = Array.from({ length: 7 }, (_, i) => ({
    date: new Date(Date.now() - (6 - i) * 24 * 60 * 60 * 1000).toLocaleDateString('en-US', { 
      month: 'short', 
      day: 'numeric' 
    }),
    score: Math.floor(Math.random() * 30) + 70,
    sleep: Math.floor(Math.random() * 30) + 70,
    recovery: Math.floor(Math.random() * 30) + 80,
  }));

  const chartData = performanceScores.length > 0 
    ? performanceScores.slice(-7).map(score => ({
        date: new Date(score.date).toLocaleDateString('en-US', { 
          month: 'short', 
          day: 'numeric' 
        }),
        score: score.overallScore,
        sleep: score.sleepScore,
        recovery: score.recoveryScore,
      }))
    : mockData;

  const currentScore = performanceScores.length > 0 
    ? performanceScores[0]?.overallScore || 84
    : 84;

  const currentHRV = wearableData?.hrv || 42;
  const hrvTrend = Math.floor(Math.random() * 10) + 3; // Mock trend

  return (
    <section className="mb-16">
      <div className="flex items-center space-x-4 mb-8">
        <div className="relative">
          <div className="w-8 h-8 rounded-full bg-primary/10 flex items-center justify-center border border-primary/20">
            <TrendingUp className="w-4 h-4 text-primary" />
          </div>
        </div>
        <div>
          <h2 className="text-3xl font-bold text-foreground">Progress Visualizer</h2>
          <p className="text-muted-foreground">Track your optimization journey over time</p>
        </div>
      </div>
      
      <div className="grid grid-cols-1 lg:grid-cols-2 gap-6">
        {/* Performance Score Chart */}
        <Card className="card-shadow glass-effect border border-border">
          <CardContent className="p-6">
            <h3 className="text-lg font-semibold text-foreground mb-4">Performance Score Trend</h3>
            <div className="h-64">
              <ResponsiveContainer width="100%" height="100%">
                <LineChart data={chartData}>
                  <CartesianGrid strokeDasharray="3 3" stroke="hsl(var(--border))" />
                  <XAxis 
                    dataKey="date" 
                    stroke="#ffffff" 
                    tick={{ fill: '#ffffff', fontSize: 12, fontWeight: 'bold' }}
                    axisLine={{ stroke: '#444444' }}
                    tickLine={{ stroke: '#444444' }}
                  />
                  <YAxis 
                    domain={[50, 100]} 
                    stroke="#ffffff" 
                    tick={{ fill: '#ffffff', fontSize: 12, fontWeight: 'bold' }}
                    axisLine={{ stroke: '#444444' }}
                    tickLine={{ stroke: '#444444' }}
                  />
                  <Tooltip 
                    contentStyle={{
                      backgroundColor: 'hsl(var(--background))',
                      border: '1px solid hsl(var(--border))',
                      borderRadius: '8px',
                      color: 'hsl(var(--foreground))'
                    }}
                  />
                  <Line 
                    type="monotone" 
                    dataKey="score" 
                    stroke="#8b5cf6" 
                    strokeWidth={3}
                    dot={{ 
                      fill: '#8b5cf6', 
                      stroke: '#ffffff',
                      strokeWidth: 2,
                      r: 6
                    }}
                    activeDot={{ r: 8, stroke: '#8b5cf6', strokeWidth: 2, fill: '#ffffff' }}
                  />
                  <Line 
                    type="monotone" 
                    dataKey="sleep" 
                    stroke="#10b981" 
                    strokeWidth={3}
                    dot={{ 
                      fill: '#10b981', 
                      stroke: '#ffffff',
                      strokeWidth: 2,
                      r: 6
                    }}
                    activeDot={{ r: 8, stroke: '#10b981', strokeWidth: 2, fill: '#ffffff' }}
                  />
                  <Line 
                    type="monotone" 
                    dataKey="recovery" 
                    stroke="#f59e0b" 
                    strokeWidth={3}
                    dot={{ 
                      fill: '#f59e0b', 
                      stroke: '#ffffff',
                      strokeWidth: 2,
                      r: 6
                    }}
                    activeDot={{ r: 8, stroke: '#f59e0b', strokeWidth: 2, fill: '#ffffff' }}
                  />
                </LineChart>
              </ResponsiveContainer>
            </div>
            <div className="mt-4 text-center">
              <div className="flex items-center justify-center space-x-6 text-sm">
                <div className="flex items-center">
                  <div className="w-4 h-4 rounded-full mr-2" style={{ backgroundColor: '#8b5cf6' }}></div>
                  <span className="text-foreground font-medium">Performance</span>
                </div>
                <div className="flex items-center">
                  <div className="w-4 h-4 rounded-full mr-2" style={{ backgroundColor: '#10b981' }}></div>
                  <span className="text-foreground font-medium">Sleep</span>
                </div>
                <div className="flex items-center">
                  <div className="w-4 h-4 rounded-full mr-2" style={{ backgroundColor: '#f59e0b' }}></div>
                  <span>Recovery</span>
                </div>
              </div>
              <p className="text-sm text-gray-500 mt-2">Current Score: {currentScore}/100</p>
            </div>
          </CardContent>
        </Card>

        {/* HRV Correlation */}
        <Card className="card-shadow">
          <CardContent className="p-6">
            <h3 className="text-lg font-semibold text-gray-900 mb-4">HRV Correlation</h3>
            <div className="h-64 flex items-center justify-center bg-gray-50 rounded-lg">
              <div className="text-center">
                <Heart className="text-red-500 text-4xl mb-4 mx-auto" />
                <p className="text-gray-600 mb-2">HRV trends vs. nutrition compliance</p>
                <p className="text-sm text-gray-500">7-day average: {currentHRV}ms (+{hrvTrend}%)</p>
                <div className="mt-4 grid grid-cols-2 gap-4 text-sm">
                  <div className="text-center">
                    <div className="text-2xl font-bold text-secondary">{currentHRV}ms</div>
                    <div className="text-gray-500">Current HRV</div>
                  </div>
                  <div className="text-center">
                    <div className="text-2xl font-bold text-primary">+{hrvTrend}%</div>
                    <div className="text-gray-500">Weekly Change</div>
                  </div>
                </div>
              </div>
            </div>
          </CardContent>
        </Card>
      </div>
    </section>
  );
}
