import { Card, CardContent } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Bed, Heart, Waves, Snowflake, Wind, Pill, RefreshCw, Zap, Target } from "lucide-react";
import { useMutation, useQueryClient } from "@tanstack/react-query";
import { apiRequest } from "@/lib/queryClient";
import { useToast } from "@/hooks/use-toast";

interface TodaysProtocolProps {
  wearableData?: {
    sleepScore: number;
    sleepDuration: string;
    strainLevel: string;
    hrv: number;
  };
  recoveryProtocols: Array<{
    type: string;
    name: string;
    description: string;
    duration: string;
  }>;
  userId: number;
}

export default function TodaysProtocol({ wearableData, recoveryProtocols, userId }: TodaysProtocolProps) {
  const queryClient = useQueryClient();
  const { toast } = useToast();

  const generateProtocolMutation = useMutation({
    mutationFn: () => apiRequest("POST", `/api/recovery-protocol/${userId}`),
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: [`/api/dashboard/${userId}`] });
      toast({
        title: "Recovery Protocol Generated",
        description: "Your personalized recovery protocol has been updated based on your latest data.",
      });
    },
    onError: () => {
      toast({
        title: "Error",
        description: "Failed to generate recovery protocol. Please try again.",
        variant: "destructive",
      });
    },
  });

  const updateDataMutation = useMutation({
    mutationFn: () => apiRequest("POST", `/api/wearable-data/${userId}`),
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: [`/api/dashboard/${userId}`] });
      toast({
        title: "Data Updated",
        description: "Your wearable data has been refreshed with the latest readings.",
      });
    },
  });

  const coldTherapyProtocol = recoveryProtocols.find(p => p.type === 'cold_therapy');
  const breathworkProtocol = recoveryProtocols.find(p => p.type === 'breathwork');
  const supplementsProtocol = recoveryProtocols.find(p => p.type === 'supplements');

  return (
    <section className="mb-16">
      <div className="flex items-center justify-between mb-8">
        <div className="flex items-center space-x-4">
          <div className="relative">
            <Target className="text-primary text-2xl" />
            <div className="absolute -top-1 -right-1 w-2 h-2 bg-secondary rounded-full pulse-ring"></div>
          </div>
          <div>
            <h2 className="text-3xl font-bold text-foreground">Today's Protocol</h2>
            <p className="text-muted-foreground">AI-optimized for your current biometric state</p>
          </div>
        </div>
        <div className="flex gap-3">
          <Button
            onClick={() => updateDataMutation.mutate()}
            disabled={updateDataMutation.isPending}
            variant="outline"
            className="glass-effect border-border hover:border-secondary/50"
          >
            <RefreshCw className={`mr-2 h-4 w-4 ${updateDataMutation.isPending ? 'animate-spin' : ''}`} />
            {updateDataMutation.isPending ? "Syncing..." : "Sync Data"}
          </Button>
          <Button
            onClick={() => generateProtocolMutation.mutate()}
            disabled={generateProtocolMutation.isPending}
            className="gradient-primary hover:scale-105 transition-all duration-300"
          >
            <Zap className="mr-2 h-4 w-4" />
            {generateProtocolMutation.isPending ? "Generating..." : "Optimize Protocol"}
          </Button>
        </div>
      </div>
      
      <div className="grid grid-cols-1 lg:grid-cols-3 gap-8">
        {/* Sleep Quality Card */}
        <Card className="card-shadow glass-effect border border-border hover:border-secondary/30 transition-all duration-300">
          <CardContent className="p-8">
            <div className="flex items-center justify-between mb-6">
              <h3 className="text-xl font-bold text-foreground">Sleep Analysis</h3>
              <div className="p-3 rounded-xl bg-secondary/10 border border-secondary/20">
                <Bed className="text-secondary text-xl" />
              </div>
            </div>
            <div className="flex items-center mb-6">
              <div className="relative w-20 h-20 mr-6">
                <div className="w-20 h-20 gradient-secondary rounded-full flex items-center justify-center border-2 border-secondary/20">
                  <span className="text-3xl font-bold text-white">
                    {wearableData?.sleepScore || 70}
                  </span>
                </div>
                <div className="absolute -top-1 -right-1 w-6 h-6 bg-secondary rounded-full flex items-center justify-center">
                  <span className="text-xs font-bold text-white">%</span>
                </div>
              </div>
              <div>
                <p className="text-lg font-semibold text-foreground">Sleep Quality</p>
                <p className="text-muted-foreground">{wearableData?.sleepDuration || "7h 30m"}</p>
                <div className="flex items-center mt-1">
                  <div className="w-2 h-2 bg-secondary rounded-full mr-2"></div>
                  <span className="text-xs text-secondary font-medium">OPTIMAL RANGE</span>
                </div>
              </div>
            </div>
            <div className="glass-effect rounded-xl p-4 border border-border">
              <p className="text-sm text-foreground font-medium">
                {wearableData?.sleepScore && wearableData.sleepScore >= 80 
                  ? "Excellent recovery detected. Your body is primed for high-intensity training."
                  : "Sub-optimal recovery. Prioritize active recovery and stress management protocols."
                }
              </p>
            </div>
          </CardContent>
        </Card>

        {/* Strain Analysis Card */}
        <Card className="card-shadow glass-effect border border-border hover:border-warning/30 transition-all duration-300">
          <CardContent className="p-8">
            <div className="flex items-center justify-between mb-6">
              <h3 className="text-xl font-bold text-foreground">Strain Analysis</h3>
              <div className="p-3 rounded-xl bg-warning/10 border border-warning/20">
                <Heart className="text-warning text-xl" />
              </div>
            </div>
            <div className="flex items-center mb-6">
              <div className="relative w-20 h-20 mr-6">
                <div className="w-20 h-20 bg-gradient-to-br from-warning to-warning/70 rounded-full flex items-center justify-center border-2 border-warning/20">
                  <span className="text-3xl font-bold text-white">
                    {wearableData?.strainLevel || "10.2"}
                  </span>
                </div>
                <div className="absolute -bottom-2 -right-2 w-8 h-8 bg-background rounded-full flex items-center justify-center border-2 border-warning">
                  <Heart className="text-warning text-xs" />
                </div>
              </div>
              <div>
                <p className="text-lg font-semibold text-foreground">Training Load</p>
                <p className="text-muted-foreground">HRV: {wearableData?.hrv || 42}ms</p>
                <div className="flex items-center mt-1">
                  <div className="w-2 h-2 bg-warning rounded-full mr-2"></div>
                  <span className="text-xs text-warning font-medium">ACTIVE MONITORING</span>
                </div>
              </div>
            </div>
            <div className="glass-effect rounded-xl p-4 border border-border">
              <p className="text-sm text-foreground font-medium">
                {wearableData?.strainLevel && parseFloat(wearableData.strainLevel) > 12
                  ? "Elevated strain detected. Implementing active recovery protocols."
                  : "Optimal strain range. Cleared for structured training sessions."
                }
              </p>
            </div>
          </CardContent>
        </Card>

        {/* Recovery Protocol Card */}
        <Card className="card-shadow glass-effect border border-border hover:border-primary/30 transition-all duration-300">
          <CardContent className="p-8">
            <div className="flex items-center justify-between mb-6">
              <h3 className="text-xl font-bold text-foreground">Recovery Protocol</h3>
              <div className="p-3 rounded-xl bg-primary/10 border border-primary/20">
                <Waves className="text-primary text-xl" />
              </div>
            </div>
            <div className="space-y-4">
              <div className="glass-effect rounded-xl p-4 border border-border hover:border-secondary/30 transition-colors">
                <div className="flex items-center">
                  <div className="p-2 rounded-lg bg-secondary/10 mr-3">
                    <Snowflake className="text-secondary h-5 w-5" />
                  </div>
                  <div className="flex-1">
                    <p className="text-sm font-medium text-foreground">Cold Therapy</p>
                    <p className="text-xs text-muted-foreground">
                      {coldTherapyProtocol?.description || "Cold exposure: 2-3 minutes at 15°C"}
                    </p>
                  </div>
                  <div className="w-2 h-2 bg-secondary rounded-full pulse-ring"></div>
                </div>
              </div>
              
              <div className="glass-effect rounded-xl p-4 border border-border hover:border-secondary/30 transition-colors">
                <div className="flex items-center">
                  <div className="p-2 rounded-lg bg-secondary/10 mr-3">
                    <Wind className="text-secondary h-5 w-5" />
                  </div>
                  <div className="flex-1">
                    <p className="text-sm font-medium text-foreground">Breathwork</p>
                    <p className="text-xs text-muted-foreground">
                      {breathworkProtocol?.description || "Box breathing: 4-4-4-4 pattern for 10 minutes"}
                    </p>
                  </div>
                  <div className="w-2 h-2 bg-secondary rounded-full pulse-ring"></div>
                </div>
              </div>
              
              <div className="glass-effect rounded-xl p-4 border border-border hover:border-secondary/30 transition-colors">
                <div className="flex items-center">
                  <div className="p-2 rounded-lg bg-secondary/10 mr-3">
                    <Pill className="text-secondary h-5 w-5" />
                  </div>
                  <div className="flex-1">
                    <p className="text-sm font-medium text-foreground">Supplements</p>
                    <p className="text-xs text-muted-foreground">
                      {supplementsProtocol?.description || "Magnesium: 400mg + Vitamin D3: 2000 IU"}
                    </p>
                  </div>
                  <div className="w-2 h-2 bg-secondary rounded-full pulse-ring"></div>
                </div>
              </div>
            </div>
          </CardContent>
        </Card>
      </div>
    </section>
  );
}
