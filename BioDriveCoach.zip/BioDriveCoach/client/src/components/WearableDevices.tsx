import { Card, CardContent } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Plus, Apple, ExternalLink, AlertCircle, CheckCircle, RefreshCw } from "lucide-react";
import { useQuery, useMutation, useQueryClient } from "@tanstack/react-query";
import { apiRequest } from "@/lib/queryClient";
import { useToast } from "@/hooks/use-toast";
import { DeviceStatus } from "@/lib/types";

interface WearableDevicesProps {
  userId: number;
}

interface WearableStatus {
  whoop?: {
    connected: boolean;
    lastSync: string;
    battery?: number;
  };
  apple_health?: {
    connected: boolean;
    lastSync: string;
    battery?: number;
  };
}

export default function WearableDevices({ userId }: WearableDevicesProps) {
  const queryClient = useQueryClient();
  const { toast } = useToast();

  const { data: deviceStatus } = useQuery<DeviceStatus>({
    queryKey: [`/api/devices/${userId}`],
    refetchInterval: 60000, // Refetch every minute
  });

  const { data: wearableStatus = {} } = useQuery<WearableStatus>({
    queryKey: [`/api/wearable-status/${userId}`],
    refetchInterval: 30000,
  });

  const connectWHOOPMutation = useMutation({
    mutationFn: async () => {
      // Store current URL to return to after auth
      localStorage.setItem('biodrive_return_url', window.location.href);
      
      toast({
        title: "Redirecting to WHOOP",
        description: "You'll be redirected back after authentication.",
      });
      
      // Direct redirect - let the server handle the OAuth flow
      setTimeout(() => {
        window.location.href = `/api/auth/whoop/${userId}`;
      }, 1000);
      
      return Promise.resolve();
    },
    onError: (error: any) => {
      toast({
        title: "Connection Failed",
        description: "Failed to connect to WHOOP. Please try again.",
        variant: "destructive",
      });
    },
  });

  const connectAppleMutation = useMutation({
    mutationFn: () => apiRequest("GET", `/api/auth/apple/${userId}`),
    onSuccess: (data: any) => {
      window.open(data.authUrl, '_blank', 'width=500,height=600');
      toast({
        title: "Apple Health Authentication",
        description: "Complete authentication in the new window.",
      });
    },
    onError: (error: any) => {
      toast({
        title: "Connection Failed",
        description: "Failed to connect to Apple Health. Please try again.",
        variant: "destructive",
      });
    },
  });

  const disconnectMutation = useMutation({
    mutationFn: (provider: string) => apiRequest("DELETE", `/api/auth/${provider}/${userId}`),
    onSuccess: (data, provider) => {
      queryClient.invalidateQueries({ queryKey: [`/api/wearable-status/${userId}`] });
      queryClient.invalidateQueries({ queryKey: [`/api/dashboard/${userId}`] });
      toast({
        title: "Device Disconnected",
        description: `${provider === 'whoop' ? 'WHOOP' : 'Apple Health'} disconnected.`,
      });
    },
  });

  const syncMutation = useMutation({
    mutationFn: () => apiRequest("POST", `/api/sync/${userId}`),
    onSuccess: (data: any) => {
      queryClient.invalidateQueries({ queryKey: [`/api/dashboard/${userId}`] });
      queryClient.invalidateQueries({ queryKey: [`/api/wearable-status/${userId}`] });
      
      console.log('Sync response:', data); // Debug log
      const successCount = data.results?.filter((r: any) => r.status === 'success').length || 0;
      const totalDevices = data.results?.length || 0;
      
      toast({
        title: "Sync Complete",
        description: successCount > 0 
          ? `Successfully synced data from ${successCount} of ${totalDevices} device(s). Fresh biometric data available!`
          : `Attempted to sync ${totalDevices} device(s). Check device connections.`,
      });
    },
    onError: (error: any) => {
      toast({
        title: "Sync Failed",
        description: "Unable to sync device data. Please try again.",
        variant: "destructive",
      });
    },
  });

  return (
    <section className="mb-16">
      <div className="flex items-center space-x-4 mb-8">
        <div className="relative">
          <div className="w-8 h-8 rounded-full bg-primary/10 flex items-center justify-center border border-primary/20">
            <div className="w-2 h-2 bg-primary rounded-full pulse-ring"></div>
          </div>
        </div>
        <div>
          <h2 className="text-3xl font-bold text-foreground">Connected Devices</h2>
          <p className="text-muted-foreground">Real-time biometric data sources</p>
        </div>
      </div>
      
      <div className="grid grid-cols-1 md:grid-cols-3 gap-6">
        {/* WHOOP Integration */}
        <Card className="card-shadow glass-effect border border-border hover:border-secondary/30 transition-all duration-300">
          <CardContent className="p-6">
            <div className="flex items-center justify-between mb-4">
              <div className="flex items-center">
                <div className="w-12 h-12 bg-gradient-to-br from-gray-800 to-gray-900 rounded-lg flex items-center justify-center mr-3 border border-border">
                  <span className="text-white font-bold text-sm">W</span>
                </div>
                <div>
                  <h3 className="font-semibold text-foreground">WHOOP</h3>
                  <p className="text-sm text-muted-foreground">
                    {wearableStatus?.whoop?.connected ? "Connected" : "Not Connected"}
                  </p>
                </div>
              </div>
              <div className={`w-3 h-3 rounded-full ${
                wearableStatus?.whoop?.connected ? "bg-secondary pulse-ring" : "bg-muted"
              }`}></div>
            </div>
            
            {wearableStatus?.whoop?.connected ? (
              <div className="space-y-3">
                <div className="flex justify-between text-sm glass-effect rounded-lg p-2 border border-border/50">
                  <span className="text-muted-foreground">Last Sync:</span>
                  <span className="text-foreground font-medium">
                    {wearableStatus.whoop.lastSync ? new Date(wearableStatus.whoop.lastSync).toLocaleTimeString() : "Never"}
                  </span>
                </div>
                <div className="flex space-x-2">
                  <Button
                    onClick={() => syncMutation.mutate()}
                    disabled={syncMutation.isPending}
                    size="sm"
                    className="flex-1 gradient-primary"
                  >
                    {syncMutation.isPending ? <RefreshCw className="w-4 h-4 animate-spin mr-2" /> : <RefreshCw className="w-4 h-4 mr-2" />}
                    Sync Now
                  </Button>
                  <Button
                    onClick={() => disconnectMutation.mutate('whoop')}
                    disabled={disconnectMutation.isPending}
                    size="sm"
                    variant="outline"
                  >
                    Disconnect
                  </Button>
                </div>
              </div>
            ) : (
              <div className="space-y-3">
                <p className="text-sm text-muted-foreground">Connect your WHOOP device to start tracking sleep, recovery, and strain data.</p>
                <Button
                  onClick={() => connectWHOOPMutation.mutate()}
                  disabled={connectWHOOPMutation.isPending}
                  className="w-full gradient-primary"
                >
                  {connectWHOOPMutation.isPending ? "Connecting..." : "Connect WHOOP"}
                  <ExternalLink className="w-4 h-4 ml-2" />
                </Button>
                {connectWHOOPMutation.isError && (
                  <p className="text-xs text-muted-foreground">
                    Having popup issues? Try refreshing the page or disabling popup blockers.
                  </p>
                )}
              </div>
            )}
          </CardContent>
        </Card>

        {/* Apple Watch Integration */}
        <Card className="card-shadow glass-effect border border-border hover:border-secondary/30 transition-all duration-300">
          <CardContent className="p-6">
            <div className="flex items-center justify-between mb-4">
              <div className="flex items-center">
                <div className="w-12 h-12 bg-gradient-to-br from-gray-800 to-gray-900 rounded-lg flex items-center justify-center mr-3 border border-border">
                  <Apple className="text-white h-6 w-6" />
                </div>
                <div>
                  <h3 className="font-semibold text-foreground">Apple Health</h3>
                  <p className="text-sm text-muted-foreground">
                    {wearableStatus?.apple_health?.connected ? "Connected" : "Not Connected"}
                  </p>
                </div>
              </div>
              <div className={`w-3 h-3 rounded-full ${
                wearableStatus?.apple_health?.connected ? "bg-secondary pulse-ring" : "bg-muted"
              }`}></div>
            </div>
            
            {wearableStatus?.apple_health?.connected ? (
              <div className="space-y-3">
                <div className="flex justify-between text-sm glass-effect rounded-lg p-2 border border-border/50">
                  <span className="text-muted-foreground">Last Sync:</span>
                  <span className="text-foreground font-medium">
                    {wearableStatus.apple_health.lastSync ? new Date(wearableStatus.apple_health.lastSync).toLocaleTimeString() : "Never"}
                  </span>
                </div>
                <div className="flex space-x-2">
                  <Button
                    onClick={() => syncMutation.mutate()}
                    disabled={syncMutation.isPending}
                    size="sm"
                    className="flex-1 gradient-primary"
                  >
                    {syncMutation.isPending ? <RefreshCw className="w-4 h-4 animate-spin mr-2" /> : <RefreshCw className="w-4 h-4 mr-2" />}
                    Sync Now
                  </Button>
                  <Button
                    onClick={() => disconnectMutation.mutate('apple_health')}
                    disabled={disconnectMutation.isPending}
                    size="sm"
                    variant="outline"
                  >
                    Disconnect
                  </Button>
                </div>
              </div>
            ) : (
              <div className="space-y-3">
                <p className="text-sm text-muted-foreground">Connect Apple Health to sync data from your iPhone and Apple Watch.</p>
                <Button
                  onClick={() => connectAppleMutation.mutate()}
                  disabled={connectAppleMutation.isPending}
                  className="w-full gradient-primary"
                >
                  {connectAppleMutation.isPending ? "Connecting..." : "Connect Apple Health"}
                  <ExternalLink className="w-4 h-4 ml-2" />
                </Button>
              </div>
            )}
          </CardContent>
        </Card>

        {/* Add Device Card */}
        <Card className="card-shadow glass-effect border-2 border-dashed border-border/50 hover:border-primary/30 transition-all duration-300">
          <CardContent className="p-6">
            <div className="text-center">
              <div className="w-12 h-12 rounded-full border-2 border-dashed border-muted-foreground mx-auto mb-4 flex items-center justify-center">
                <Plus className="text-muted-foreground h-6 w-6" />
              </div>
              <h3 className="font-semibold text-foreground mb-2">Add Device</h3>
              <p className="text-sm text-muted-foreground mb-4">Connect more wearables for enhanced optimization</p>
              <Button className="gradient-primary hover:scale-105 transition-all duration-300">
                Connect Device
              </Button>
            </div>
          </CardContent>
        </Card>
      </div>
    </section>
  );
}
