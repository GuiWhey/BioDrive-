import { useState } from "react";
import { useQuery } from "@tanstack/react-query";
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Badge } from "@/components/ui/badge";
import { Separator } from "@/components/ui/separator";
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs";
import { Progress } from "@/components/ui/progress";
import { 
  History, 
  TrendingUp, 
  Calendar, 
  CheckCircle, 
  Clock, 
  Target, 
  Brain,
  BarChart3,
  Trophy,
  Zap
} from "lucide-react";
import { format, subDays, isAfter } from "date-fns";

interface CoachingHistoryProps {
  userId: number;
}

interface CoachingSession {
  id: number;
  personalizedMessage: string;
  keyInsights: string[];
  weeklyFocus: string;
  motivationalNote: string;
  nextCheckIn: string;
  performanceTrend: number;
  createdAt: string;
}

interface CoachingRecommendation {
  id: number;
  sessionId: number;
  priority: 'high' | 'medium' | 'low';
  category: 'sleep' | 'recovery' | 'nutrition' | 'training' | 'stress';
  title: string;
  description: string;
  timeframe: string;
  completed: boolean;
  createdAt: string;
}

const categoryColors = {
  sleep: "bg-blue-500/10 text-blue-400 border-blue-500/20",
  recovery: "bg-green-500/10 text-green-400 border-green-500/20",
  nutrition: "bg-orange-500/10 text-orange-400 border-orange-500/20",
  training: "bg-purple-500/10 text-purple-400 border-purple-500/20",
  stress: "bg-red-500/10 text-red-400 border-red-500/20"
};

const priorityColors = {
  high: "bg-red-500/10 text-red-500 border-red-500/20",
  medium: "bg-orange-500/10 text-orange-500 border-orange-500/20",
  low: "bg-blue-500/10 text-blue-500 border-blue-500/20"
};

export default function CoachingHistory({ userId }: CoachingHistoryProps) {
  const [selectedSession, setSelectedSession] = useState<number | null>(null);

  const { data: sessions, isLoading } = useQuery<CoachingSession[]>({
    queryKey: ['/api/coaching/sessions', userId],
    enabled: !!userId,
  });

  const { data: allRecommendations } = useQuery<CoachingRecommendation[]>({
    queryKey: ['/api/coaching/recommendations/all', userId],
    enabled: !!userId,
  });

  if (isLoading) {
    return (
      <Card className="bg-zinc-900/50 border-zinc-800">
        <CardHeader>
          <div className="flex items-center gap-2">
            <History className="h-5 w-5 text-indigo-400" />
            <CardTitle className="text-white">Coaching History</CardTitle>
          </div>
        </CardHeader>
        <CardContent>
          <div className="animate-pulse space-y-4">
            <div className="h-4 bg-zinc-700 rounded w-3/4"></div>
            <div className="h-4 bg-zinc-700 rounded w-1/2"></div>
            <div className="h-20 bg-zinc-700 rounded"></div>
          </div>
        </CardContent>
      </Card>
    );
  }

  // Calculate analytics
  const totalSessions = sessions?.length || 0;
  const totalRecommendations = allRecommendations?.length || 0;
  const completedRecommendations = allRecommendations?.filter(r => r.completed).length || 0;
  const completionRate = totalRecommendations > 0 ? (completedRecommendations / totalRecommendations) * 100 : 0;

  // Recent performance trend
  const recentSessions = sessions?.slice(0, 5) || [];
  const avgPerformanceTrend = recentSessions.reduce((acc, session) => acc + session.performanceTrend, 0) / recentSessions.length || 0;

  // Category breakdown
  const categoryStats = allRecommendations?.reduce((acc, rec) => {
    acc[rec.category] = (acc[rec.category] || 0) + 1;
    return acc;
  }, {} as Record<string, number>) || {};

  // Recent activity (last 30 days)
  const thirtyDaysAgo = subDays(new Date(), 30);
  const recentActivity = sessions?.filter(session => 
    isAfter(new Date(session.createdAt), thirtyDaysAgo)
  ).length || 0;

  return (
    <Card className="bg-gradient-to-br from-indigo-900/20 to-purple-900/20 border-indigo-500/20">
      <CardHeader>
        <div className="flex items-center gap-2">
          <History className="h-5 w-5 text-indigo-400" />
          <div>
            <CardTitle className="text-white">Coaching Journey</CardTitle>
            <CardDescription className="text-zinc-400">
              Track your progress and insights over time
            </CardDescription>
          </div>
        </div>
      </CardHeader>

      <CardContent>
        <Tabs defaultValue="overview" className="space-y-6">
          <TabsList className="grid w-full grid-cols-3 bg-zinc-800/50">
            <TabsTrigger value="overview" className="text-zinc-300 data-[state=active]:text-white">
              Overview
            </TabsTrigger>
            <TabsTrigger value="sessions" className="text-zinc-300 data-[state=active]:text-white">
              Sessions
            </TabsTrigger>
            <TabsTrigger value="analytics" className="text-zinc-300 data-[state=active]:text-white">
              Analytics
            </TabsTrigger>
          </TabsList>

          <TabsContent value="overview" className="space-y-6">
            {/* Key Metrics */}
            <div className="grid grid-cols-2 md:grid-cols-4 gap-4">
              <div className="p-4 bg-zinc-900/50 rounded-lg border border-zinc-700">
                <div className="flex items-center gap-2 mb-2">
                  <Brain className="h-4 w-4 text-indigo-400" />
                  <span className="text-xs text-zinc-400">Total Sessions</span>
                </div>
                <div className="text-2xl font-bold text-white">{totalSessions}</div>
              </div>

              <div className="p-4 bg-zinc-900/50 rounded-lg border border-zinc-700">
                <div className="flex items-center gap-2 mb-2">
                  <Target className="h-4 w-4 text-green-400" />
                  <span className="text-xs text-zinc-400">Completion Rate</span>
                </div>
                <div className="text-2xl font-bold text-white">{completionRate.toFixed(0)}%</div>
              </div>

              <div className="p-4 bg-zinc-900/50 rounded-lg border border-zinc-700">
                <div className="flex items-center gap-2 mb-2">
                  <TrendingUp className="h-4 w-4 text-purple-400" />
                  <span className="text-xs text-zinc-400">Avg Trend</span>
                </div>
                <div className={`text-2xl font-bold ${avgPerformanceTrend >= 0 ? 'text-green-400' : 'text-red-400'}`}>
                  {avgPerformanceTrend >= 0 ? '+' : ''}{avgPerformanceTrend.toFixed(1)}
                </div>
              </div>

              <div className="p-4 bg-zinc-900/50 rounded-lg border border-zinc-700">
                <div className="flex items-center gap-2 mb-2">
                  <Zap className="h-4 w-4 text-yellow-400" />
                  <span className="text-xs text-zinc-400">Recent Activity</span>
                </div>
                <div className="text-2xl font-bold text-white">{recentActivity}</div>
                <div className="text-xs text-zinc-500">Last 30 days</div>
              </div>
            </div>

            {/* Progress Overview */}
            <div className="p-4 bg-zinc-900/50 rounded-lg border border-zinc-700">
              <h3 className="text-white font-medium mb-3 flex items-center gap-2">
                <Trophy className="h-4 w-4 text-yellow-400" />
                Recommendation Progress
              </h3>
              <div className="space-y-3">
                <div className="flex justify-between text-sm">
                  <span className="text-zinc-300">Completed</span>
                  <span className="text-white">{completedRecommendations} / {totalRecommendations}</span>
                </div>
                <Progress value={completionRate} className="h-2" />
                <div className="flex justify-between text-xs text-zinc-500">
                  <span>Keep going!</span>
                  <span>{completionRate.toFixed(1)}% complete</span>
                </div>
              </div>
            </div>

            {/* Category Breakdown */}
            <div className="p-4 bg-zinc-900/50 rounded-lg border border-zinc-700">
              <h3 className="text-white font-medium mb-3 flex items-center gap-2">
                <BarChart3 className="h-4 w-4 text-blue-400" />
                Focus Areas
              </h3>
              <div className="grid grid-cols-2 md:grid-cols-5 gap-2">
                {Object.entries(categoryStats).map(([category, count]) => (
                  <div key={category} className="text-center">
                    <div className={`text-xs px-2 py-1 rounded-full ${categoryColors[category as keyof typeof categoryColors]}`}>
                      {category}
                    </div>
                    <div className="text-lg font-bold text-white mt-1">{count}</div>
                  </div>
                ))}
              </div>
            </div>
          </TabsContent>

          <TabsContent value="sessions" className="space-y-4">
            {sessions && sessions.length > 0 ? (
              <div className="space-y-4">
                {sessions.map((session) => (
                  <div
                    key={session.id}
                    className={`p-4 rounded-lg border transition-all cursor-pointer ${
                      selectedSession === session.id
                        ? 'bg-indigo-900/30 border-indigo-500/50'
                        : 'bg-zinc-900/50 border-zinc-700 hover:border-zinc-600'
                    }`}
                    onClick={() => setSelectedSession(selectedSession === session.id ? null : session.id)}
                  >
                    <div className="flex items-start justify-between mb-2">
                      <div className="flex items-center gap-2">
                        <Calendar className="h-4 w-4 text-indigo-400" />
                        <span className="text-white font-medium">
                          {format(new Date(session.createdAt), 'MMM dd, yyyy')}
                        </span>
                        {session.performanceTrend !== 0 && (
                          <Badge 
                            variant="outline" 
                            className={`text-xs ${session.performanceTrend > 0 ? 'text-green-400 border-green-500/30' : 'text-red-400 border-red-500/30'}`}
                          >
                            {session.performanceTrend > 0 ? '+' : ''}{session.performanceTrend.toFixed(1)}
                          </Badge>
                        )}
                      </div>
                      <span className="text-xs text-zinc-500">
                        {format(new Date(session.createdAt), 'h:mm a')}
                      </span>
                    </div>

                    <p className="text-zinc-300 text-sm line-clamp-2 mb-2">
                      {session.personalizedMessage}
                    </p>

                    <div className="flex items-center gap-2 text-xs text-zinc-500">
                      <span>Focus: {session.weeklyFocus}</span>
                    </div>

                    {selectedSession === session.id && (
                      <div className="mt-4 pt-4 border-t border-zinc-700 space-y-3">
                        <div>
                          <h4 className="text-white font-medium mb-2">Key Insights</h4>
                          <ul className="space-y-1">
                            {session.keyInsights.map((insight, index) => (
                              <li key={index} className="text-zinc-300 text-sm flex items-start gap-2">
                                <div className="w-1 h-1 bg-indigo-400 rounded-full mt-2 flex-shrink-0" />
                                {insight}
                              </li>
                            ))}
                          </ul>
                        </div>

                        <Separator className="bg-zinc-700" />

                        <div className="p-3 bg-indigo-900/20 rounded-lg">
                          <h4 className="text-white font-medium mb-1 flex items-center gap-2">
                            <Trophy className="h-3 w-3 text-yellow-400" />
                            Motivation
                          </h4>
                          <p className="text-indigo-300 text-sm">{session.motivationalNote}</p>
                        </div>
                      </div>
                    )}
                  </div>
                ))}
              </div>
            ) : (
              <div className="text-center py-8">
                <Brain className="h-12 w-12 text-indigo-400 mx-auto mb-4" />
                <h3 className="text-white font-medium mb-2">No Coaching Sessions Yet</h3>
                <p className="text-zinc-400">
                  Start your first AI coaching session to begin tracking your progress.
                </p>
              </div>
            )}
          </TabsContent>

          <TabsContent value="analytics" className="space-y-6">
            {/* Performance Trends */}
            <div className="p-4 bg-zinc-900/50 rounded-lg border border-zinc-700">
              <h3 className="text-white font-medium mb-4 flex items-center gap-2">
                <TrendingUp className="h-4 w-4 text-purple-400" />
                Performance Trends
              </h3>
              
              {recentSessions.length > 0 ? (
                <div className="space-y-3">
                  {recentSessions.map((session, index) => (
                    <div key={session.id} className="flex items-center gap-3">
                      <div className="text-xs text-zinc-500 w-20">
                        {format(new Date(session.createdAt), 'MMM dd')}
                      </div>
                      <div className="flex-1">
                        <div className="flex items-center gap-2">
                          <div className={`w-2 h-2 rounded-full ${
                            session.performanceTrend > 0 ? 'bg-green-400' : 
                            session.performanceTrend < 0 ? 'bg-red-400' : 'bg-zinc-500'
                          }`} />
                          <span className={`text-sm ${
                            session.performanceTrend > 0 ? 'text-green-400' : 
                            session.performanceTrend < 0 ? 'text-red-400' : 'text-zinc-400'
                          }`}>
                            {session.performanceTrend > 0 ? '+' : ''}{session.performanceTrend.toFixed(1)} points
                          </span>
                        </div>
                      </div>
                    </div>
                  ))}
                </div>
              ) : (
                <p className="text-zinc-500 text-sm">Not enough data for trend analysis</p>
              )}
            </div>

            {/* Recommendation Analytics */}
            <div className="grid md:grid-cols-2 gap-4">
              <div className="p-4 bg-zinc-900/50 rounded-lg border border-zinc-700">
                <h3 className="text-white font-medium mb-3">Priority Distribution</h3>
                <div className="space-y-2">
                  {['high', 'medium', 'low'].map(priority => {
                    const count = allRecommendations?.filter(r => r.priority === priority).length || 0;
                    const percentage = totalRecommendations > 0 ? (count / totalRecommendations) * 100 : 0;
                    return (
                      <div key={priority} className="flex items-center gap-3">
                        <div className={`text-xs px-2 py-1 rounded-full capitalize ${priorityColors[priority as keyof typeof priorityColors]}`}>
                          {priority}
                        </div>
                        <div className="flex-1">
                          <div className="flex justify-between text-sm mb-1">
                            <span className="text-zinc-300">{count}</span>
                            <span className="text-zinc-500">{percentage.toFixed(0)}%</span>
                          </div>
                          <Progress value={percentage} className="h-1" />
                        </div>
                      </div>
                    );
                  })}
                </div>
              </div>

              <div className="p-4 bg-zinc-900/50 rounded-lg border border-zinc-700">
                <h3 className="text-white font-medium mb-3">Completion by Category</h3>
                <div className="space-y-2">
                  {Object.entries(categoryStats).map(([category, total]) => {
                    const completed = allRecommendations?.filter(r => 
                      r.category === category && r.completed
                    ).length || 0;
                    const percentage = total > 0 ? (completed / total) * 100 : 0;
                    return (
                      <div key={category} className="flex items-center gap-3">
                        <div className={`text-xs px-2 py-1 rounded-full capitalize ${categoryColors[category as keyof typeof categoryColors]}`}>
                          {category}
                        </div>
                        <div className="flex-1">
                          <div className="flex justify-between text-sm mb-1">
                            <span className="text-zinc-300">{completed}/{total}</span>
                            <span className="text-zinc-500">{percentage.toFixed(0)}%</span>
                          </div>
                          <Progress value={percentage} className="h-1" />
                        </div>
                      </div>
                    );
                  })}
                </div>
              </div>
            </div>
          </TabsContent>
        </Tabs>
      </CardContent>
    </Card>
  );
}