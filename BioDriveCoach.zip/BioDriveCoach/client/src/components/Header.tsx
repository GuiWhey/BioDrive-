import { Bell, ChartLine, Zap, Shield } from "lucide-react";

export default function Header() {
  return (
    <header className="glass-effect border-b border-border relative z-30">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        <div className="flex justify-between items-center h-20">
          <div className="flex items-center">
            <div className="flex-shrink-0 flex items-center">
              <div className="relative">
                <Shield className="text-primary text-3xl mr-3" />
                <div className="absolute -top-1 -right-1 w-2 h-2 bg-secondary rounded-full pulse-ring"></div>
              </div>
              <span className="text-2xl font-bold bg-gradient-to-r from-primary to-secondary bg-clip-text text-transparent">BioDrive+</span>
            </div>
          </div>
          <nav className="hidden md:flex space-x-8">
            <a href="#" className="text-foreground hover:text-primary transition-colors font-medium relative group">
              Dashboard
              <div className="absolute bottom-0 left-0 w-0 h-0.5 bg-primary group-hover:w-full transition-all duration-300"></div>
            </a>
            <a href="#" className="text-muted-foreground hover:text-primary transition-colors font-medium relative group">
              Protocols
              <div className="absolute bottom-0 left-0 w-0 h-0.5 bg-primary group-hover:w-full transition-all duration-300"></div>
            </a>
            <a href="#" className="text-muted-foreground hover:text-primary transition-colors font-medium relative group">
              Nutrition
              <div className="absolute bottom-0 left-0 w-0 h-0.5 bg-primary group-hover:w-full transition-all duration-300"></div>
            </a>
            <a href="#" className="text-muted-foreground hover:text-primary transition-colors font-medium relative group">
              Recovery
              <div className="absolute bottom-0 left-0 w-0 h-0.5 bg-primary group-hover:w-full transition-all duration-300"></div>
            </a>
            <a href="#" className="text-muted-foreground hover:text-primary transition-colors font-medium relative group">
              Analytics
              <div className="absolute bottom-0 left-0 w-0 h-0.5 bg-primary group-hover:w-full transition-all duration-300"></div>
            </a>
          </nav>
          <div className="flex items-center space-x-6">
            <div className="flex items-center space-x-2 px-3 py-1.5 glass-effect rounded-full border border-secondary/20">
              <Zap className="h-4 w-4 text-secondary" />
              <span className="text-sm font-medium text-secondary">Elite</span>
            </div>
            <button className="relative p-3 text-muted-foreground hover:text-primary transition-colors">
              <Bell className="h-6 w-6" />
              <div className="absolute top-2 right-2 w-2 h-2 bg-secondary rounded-full"></div>
            </button>
            <div className="w-10 h-10 gradient-primary rounded-full flex items-center justify-center border-2 border-primary/20">
              <span className="text-white text-sm font-bold">JD</span>
            </div>
          </div>
        </div>
      </div>
    </header>
  );
}
