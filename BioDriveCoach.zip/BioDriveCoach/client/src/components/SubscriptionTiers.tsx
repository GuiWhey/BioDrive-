import { Card, CardContent } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Check } from "lucide-react";

interface SubscriptionTiersProps {
  currentTier: string;
}

export default function SubscriptionTiers({ currentTier }: SubscriptionTiersProps) {
  const tiers = [
    {
      name: "Basic",
      price: "$9",
      description: "Essential optimization",
      features: [
        "Basic daily protocols",
        "Wearable integration",
        "Weekly meal plans",
      ],
      isCurrent: currentTier === "basic",
      isPopular: false,
    },
    {
      name: "Pro",
      price: "$19",
      description: "Advanced AI coaching",
      features: [
        "Everything in Basic",
        "AI meal generation",
        "Advanced recovery protocols",
        "Performance analytics",
      ],
      isCurrent: currentTier === "pro",
      isPopular: true,
    },
    {
      name: "Elite",
      price: "$49",
      description: "Personal AI coach",
      features: [
        "Everything in Pro",
        "1:1 AI coaching",
        "Custom supplement plans",
        "Priority support",
      ],
      isCurrent: currentTier === "elite",
      isPopular: false,
    },
  ];

  return (
    <section className="mb-16">
      <div className="flex items-center space-x-4 mb-8">
        <div className="relative">
          <div className="w-8 h-8 rounded-full bg-primary/10 flex items-center justify-center border border-primary/20">
            <div className="w-2 h-2 bg-primary rounded-full pulse-ring"></div>
          </div>
        </div>
        <div>
          <h2 className="text-3xl font-bold text-foreground">Upgrade Your Experience</h2>
          <p className="text-muted-foreground">Choose the plan that fits your optimization goals</p>
        </div>
      </div>
      
      <div className="grid grid-cols-1 md:grid-cols-3 gap-6">
        {tiers.map((tier) => (
          <Card 
            key={tier.name}
            className={`card-shadow glass-effect relative border transition-all duration-300 hover:scale-105 ${
              tier.isPopular ? "border-primary/50 shadow-primary/20" : "border-border hover:border-primary/30"
            }`}
          >
            {tier.isPopular && (
              <div className="absolute -top-3 left-1/2 transform -translate-x-1/2">
                <span className="bg-gradient-to-r from-primary to-secondary text-white px-4 py-1 rounded-full text-sm font-medium border border-primary/20">
                  Most Popular
                </span>
              </div>
            )}
            <CardContent className={`p-6 ${tier.isPopular ? "mt-4" : ""}`}>
              <div className="text-center mb-6">
                <h3 className="text-xl font-semibold text-foreground mb-2">{tier.name}</h3>
                <div className="text-3xl font-bold text-foreground mb-1">
                  {tier.price}
                  <span className="text-lg font-normal text-muted-foreground">/mo</span>
                </div>
                <p className="text-sm text-muted-foreground">{tier.description}</p>
              </div>
              <ul className="space-y-3 mb-6">
                {tier.features.map((feature, index) => (
                  <li key={index} className="flex items-center text-sm text-foreground">
                    <Check className="text-secondary mr-3 h-4 w-4 flex-shrink-0" />
                    <span>{feature}</span>
                  </li>
                ))}
              </ul>
              <Button 
                className={`w-full transition-all duration-300 ${
                  tier.isCurrent 
                    ? "bg-muted text-muted-foreground hover:bg-muted/80" 
                    : tier.isPopular
                    ? "gradient-primary hover:scale-105"
                    : tier.name === "Elite"
                    ? "bg-gradient-to-r from-primary to-purple-600 text-white hover:from-primary/90 hover:to-purple-700 hover:scale-105"
                    : "gradient-primary hover:scale-105"
                }`}
                disabled={tier.isCurrent}
              >
                {tier.isCurrent 
                  ? "Current Plan" 
                  : tier.name === "Elite"
                  ? "Go Elite"
                  : `Upgrade to ${tier.name}`
                }
              </Button>
            </CardContent>
          </Card>
        ))}
      </div>
    </section>
  );
}
