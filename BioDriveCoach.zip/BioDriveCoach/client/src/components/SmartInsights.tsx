import { useState } from "react";
import { useQuery } from "@tanstack/react-query";
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card";
import { Badge } from "@/components/ui/badge";
import { Button } from "@/components/ui/button";
import { Progress } from "@/components/ui/progress";
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs";
import { 
  Lightbulb, 
  TrendingUp, 
  TrendingDown, 
  AlertTriangle, 
  CheckCircle,
  Calendar,
  Clock,
  Target,
  Zap,
  Brain,
  Activity,
  Moon,
  Heart
} from "lucide-react";
import { format, subDays, startOfWeek, endOfWeek, isWithinInterval } from "date-fns";

interface SmartInsightsProps {
  userId: number;
}

interface PerformanceScore {
  id: number;
  sleepScore: number;
  recoveryScore: number;
  strainLevel: string;
  overallScore: number;
  date: string;
}

interface WearableData {
  sleepScore: number;
  sleepDuration: string;
  strainLevel: number;
  hrv: number;
  heartRate: number;
  deviceType: string;
}

interface Insight {
  type: 'trend' | 'pattern' | 'alert' | 'achievement';
  title: string;
  description: string;
  impact: 'high' | 'medium' | 'low';
  category: 'sleep' | 'recovery' | 'performance' | 'consistency';
  actionable?: string;
  confidence: number;
}

const insightIcons = {
  trend: TrendingUp,
  pattern: Activity,
  alert: AlertTriangle,
  achievement: CheckCircle
};

const impactColors = {
  high: "bg-red-500/10 text-red-400 border-red-500/20",
  medium: "bg-orange-500/10 text-orange-400 border-orange-500/20",
  low: "bg-blue-500/10 text-blue-400 border-blue-500/20"
};

const categoryIcons = {
  sleep: Moon,
  recovery: Heart,
  performance: Zap,
  consistency: Target
};

export default function SmartInsights({ userId }: SmartInsightsProps) {
  const [timeframe, setTimeframe] = useState<'week' | 'month' | 'quarter'>('week');

  const { data: performanceScores } = useQuery<PerformanceScore[]>({
    queryKey: [`/api/performance-scores/${userId}`],
    enabled: !!userId,
  });

  const { data: dashboardData } = useQuery({
    queryKey: [`/api/dashboard/${userId}`],
    enabled: !!userId,
  });

  const wearableData = dashboardData?.wearableData as WearableData | undefined;

  // Generate smart insights based on data patterns
  const generateInsights = (): Insight[] => {
    const insights: Insight[] = [];
    
    if (!performanceScores || performanceScores.length < 3) {
      return [{
        type: 'alert',
        title: 'Insufficient Data',
        description: 'Need more data points to generate meaningful insights. Keep tracking for at least a week.',
        impact: 'medium',
        category: 'consistency',
        confidence: 90
      }];
    }

    const recent = performanceScores.slice(0, 7);
    const older = performanceScores.slice(7, 14);

    // Performance trend analysis
    const recentAvg = recent.reduce((acc, score) => acc + score.overallScore, 0) / recent.length;
    const olderAvg = older.length > 0 ? older.reduce((acc, score) => acc + score.overallScore, 0) / older.length : recentAvg;
    const trendDiff = recentAvg - olderAvg;

    if (Math.abs(trendDiff) > 5) {
      insights.push({
        type: trendDiff > 0 ? 'achievement' : 'trend',
        title: trendDiff > 0 ? 'Performance Improving' : 'Performance Declining',
        description: `Your overall performance has ${trendDiff > 0 ? 'improved' : 'declined'} by ${Math.abs(trendDiff).toFixed(1)} points over the past week.`,
        impact: Math.abs(trendDiff) > 10 ? 'high' : 'medium',
        category: 'performance',
        actionable: trendDiff > 0 ? 'Keep up the excellent work!' : 'Consider reviewing your recovery and sleep habits.',
        confidence: 85
      });
    }

    // Sleep pattern analysis
    const sleepScores = recent.map(s => s.sleepScore).filter(s => s !== null);
    if (sleepScores.length > 3) {
      const avgSleep = sleepScores.reduce((acc, score) => acc + score, 0) / sleepScores.length;
      const sleepVariability = Math.sqrt(sleepScores.reduce((acc, score) => acc + Math.pow(score - avgSleep, 2), 0) / sleepScores.length);

      if (avgSleep < 70) {
        insights.push({
          type: 'alert',
          title: 'Poor Sleep Quality',
          description: `Your average sleep score is ${avgSleep.toFixed(1)}, which is below optimal levels.`,
          impact: 'high',
          category: 'sleep',
          actionable: 'Focus on consistent bedtime routines and sleep environment optimization.',
          confidence: 90
        });
      }

      if (sleepVariability > 15) {
        insights.push({
          type: 'pattern',
          title: 'Inconsistent Sleep',
          description: `Your sleep quality varies significantly (${sleepVariability.toFixed(1)} point variance). Consistency is key for optimization.`,
          impact: 'medium',
          category: 'sleep',
          actionable: 'Try maintaining consistent sleep and wake times, even on weekends.',
          confidence: 75
        });
      }
    }

    // Recovery analysis
    const recoveryScores = recent.map(s => s.recoveryScore).filter(s => s !== null);
    if (recoveryScores.length > 3) {
      const avgRecovery = recoveryScores.reduce((acc, score) => acc + score, 0) / recoveryScores.length;
      
      if (avgRecovery < 70) {
        insights.push({
          type: 'alert',
          title: 'Recovery Needs Attention',
          description: `Your recovery score averages ${avgRecovery.toFixed(1)}, indicating your body may need more rest.`,
          impact: 'high',
          category: 'recovery',
          actionable: 'Consider incorporating more active recovery days and stress management techniques.',
          confidence: 85
        });
      }
    }

    // Strain analysis
    if (wearableData?.strainLevel) {
      const strain = wearableData.strainLevel;
      if (strain > 18) {
        insights.push({
          type: 'alert',
          title: 'High Strain Detected',
          description: `Current strain level is ${strain}, which is quite high. Your body may need recovery.`,
          impact: 'high',
          category: 'recovery',
          actionable: 'Consider a lighter training day or active recovery session.',
          confidence: 95
        });
      } else if (strain < 8) {
        insights.push({
          type: 'pattern',
          title: 'Low Activity Detected',
          description: `Your strain level is ${strain}, indicating low physical activity. You might have room to increase activity.`,
          impact: 'medium',
          category: 'performance',
          actionable: 'Consider gradually increasing your training intensity.',
          confidence: 80
        });
      }
    }

    // Consistency patterns
    const weeklyConsistency = recent.length / 7;
    if (weeklyConsistency < 0.7) {
      insights.push({
        type: 'pattern',
        title: 'Inconsistent Tracking',
        description: `You've only tracked ${Math.round(weeklyConsistency * 100)}% of days this week. Consistent data helps AI coaching.`,
        impact: 'medium',
        category: 'consistency',
        actionable: 'Try to sync your wearable device daily for better insights.',
        confidence: 90
      });
    }

    // HRV insights
    if (wearableData?.hrv) {
      const hrv = wearableData.hrv;
      if (hrv < 25) {
        insights.push({
          type: 'alert',
          title: 'Low HRV Detected',
          description: `Your HRV is ${hrv}ms, which may indicate stress or fatigue.`,
          impact: 'high',
          category: 'recovery',
          actionable: 'Focus on stress reduction, deep breathing, and prioritize sleep quality.',
          confidence: 85
        });
      } else if (hrv > 50) {
        insights.push({
          type: 'achievement',
          title: 'Excellent HRV',
          description: `Your HRV of ${hrv}ms indicates good recovery and autonomic balance.`,
          impact: 'low',
          category: 'recovery',
          actionable: 'Great work! You can likely handle higher training loads.',
          confidence: 90
        });
      }
    }

    return insights.sort((a, b) => {
      const impactWeight = { high: 3, medium: 2, low: 1 };
      return impactWeight[b.impact] - impactWeight[a.impact];
    });
  };

  const insights = generateInsights();

  // Weekly summary stats
  const thisWeekStart = startOfWeek(new Date());
  const thisWeekEnd = endOfWeek(new Date());
  const thisWeekScores = performanceScores?.filter(score => 
    isWithinInterval(new Date(score.date), { start: thisWeekStart, end: thisWeekEnd })
  ) || [];

  const weeklyAvg = thisWeekScores.length > 0 
    ? thisWeekScores.reduce((acc, score) => acc + score.overallScore, 0) / thisWeekScores.length 
    : 0;

  const lastWeekStart = subDays(thisWeekStart, 7);
  const lastWeekEnd = subDays(thisWeekEnd, 7);
  const lastWeekScores = performanceScores?.filter(score => 
    isWithinInterval(new Date(score.date), { start: lastWeekStart, end: lastWeekEnd })
  ) || [];

  const lastWeekAvg = lastWeekScores.length > 0 
    ? lastWeekScores.reduce((acc, score) => acc + score.overallScore, 0) / lastWeekScores.length 
    : 0;

  const weeklyChange = weeklyAvg - lastWeekAvg;

  return (
    <Card className="bg-gradient-to-br from-violet-900/20 to-cyan-900/20 border-violet-500/20">
      <CardHeader>
        <div className="flex items-center gap-2">
          <Lightbulb className="h-5 w-5 text-violet-400" />
          <div>
            <CardTitle className="text-white">Smart Insights</CardTitle>
            <CardDescription className="text-zinc-400">
              AI-powered pattern analysis and predictions
            </CardDescription>
          </div>
        </div>
      </CardHeader>

      <CardContent>
        <Tabs defaultValue="insights" className="space-y-6">
          <TabsList className="grid w-full grid-cols-3 bg-zinc-800/50">
            <TabsTrigger value="insights" className="text-zinc-300 data-[state=active]:text-white">
              Insights
            </TabsTrigger>
            <TabsTrigger value="patterns" className="text-zinc-300 data-[state=active]:text-white">
              Patterns
            </TabsTrigger>
            <TabsTrigger value="predictions" className="text-zinc-300 data-[state=active]:text-white">
              Predictions
            </TabsTrigger>
          </TabsList>

          <TabsContent value="insights" className="space-y-4">
            {insights.length > 0 ? (
              <div className="space-y-4">
                {insights.slice(0, 6).map((insight, index) => {
                  const IconComponent = insightIcons[insight.type];
                  const CategoryIcon = categoryIcons[insight.category];
                  
                  return (
                    <div
                      key={index}
                      className="p-4 bg-zinc-900/50 rounded-lg border border-zinc-700 hover:border-zinc-600 transition-all"
                    >
                      <div className="flex items-start gap-3">
                        <div className={`p-2 rounded-lg ${
                          insight.type === 'achievement' ? 'bg-green-500/20' :
                          insight.type === 'alert' ? 'bg-red-500/20' :
                          insight.type === 'trend' ? 'bg-purple-500/20' :
                          'bg-blue-500/20'
                        }`}>
                          <IconComponent className={`h-4 w-4 ${
                            insight.type === 'achievement' ? 'text-green-400' :
                            insight.type === 'alert' ? 'text-red-400' :
                            insight.type === 'trend' ? 'text-purple-400' :
                            'text-blue-400'
                          }`} />
                        </div>
                        
                        <div className="flex-1 space-y-2">
                          <div className="flex items-center gap-2 flex-wrap">
                            <h4 className="text-white font-medium">{insight.title}</h4>
                            <Badge 
                              variant="outline" 
                              className={`text-xs ${impactColors[insight.impact]}`}
                            >
                              {insight.impact} impact
                            </Badge>
                            <div className="flex items-center gap-1 text-xs text-zinc-500">
                              <CategoryIcon className="h-3 w-3" />
                              <span>{insight.category}</span>
                            </div>
                          </div>
                          
                          <p className="text-zinc-300 text-sm leading-relaxed">
                            {insight.description}
                          </p>
                          
                          {insight.actionable && (
                            <div className="p-2 bg-violet-900/20 rounded border border-violet-500/20">
                              <p className="text-violet-300 text-sm font-medium">
                                💡 {insight.actionable}
                              </p>
                            </div>
                          )}
                          
                          <div className="flex items-center gap-2 text-xs text-zinc-500">
                            <span>Confidence: {insight.confidence}%</span>
                            <Progress value={insight.confidence} className="h-1 w-16" />
                          </div>
                        </div>
                      </div>
                    </div>
                  );
                })}
              </div>
            ) : (
              <div className="text-center py-8">
                <Brain className="h-12 w-12 text-violet-400 mx-auto mb-4" />
                <h3 className="text-white font-medium mb-2">Analyzing Your Data</h3>
                <p className="text-zinc-400">
                  Keep tracking your metrics to unlock personalized insights.
                </p>
              </div>
            )}
          </TabsContent>

          <TabsContent value="patterns" className="space-y-6">
            {/* Weekly Performance Summary */}
            <div className="p-4 bg-zinc-900/50 rounded-lg border border-zinc-700">
              <h3 className="text-white font-medium mb-4 flex items-center gap-2">
                <Calendar className="h-4 w-4 text-cyan-400" />
                Weekly Performance Summary
              </h3>
              
              <div className="grid grid-cols-2 md:grid-cols-4 gap-4">
                <div className="text-center">
                  <div className="text-2xl font-bold text-white">{weeklyAvg.toFixed(1)}</div>
                  <div className="text-xs text-zinc-400">This Week Avg</div>
                </div>
                
                <div className="text-center">
                  <div className={`text-2xl font-bold ${weeklyChange >= 0 ? 'text-green-400' : 'text-red-400'}`}>
                    {weeklyChange >= 0 ? '+' : ''}{weeklyChange.toFixed(1)}
                  </div>
                  <div className="text-xs text-zinc-400">vs Last Week</div>
                </div>
                
                <div className="text-center">
                  <div className="text-2xl font-bold text-white">{thisWeekScores.length}</div>
                  <div className="text-xs text-zinc-400">Days Tracked</div>
                </div>
                
                <div className="text-center">
                  <div className="text-2xl font-bold text-white">
                    {thisWeekScores.length > 0 ? Math.max(...thisWeekScores.map(s => s.overallScore)).toFixed(0) : '0'}
                  </div>
                  <div className="text-xs text-zinc-400">Best Day</div>
                </div>
              </div>
            </div>

            {/* Sleep Patterns */}
            {wearableData && (
              <div className="grid md:grid-cols-2 gap-4">
                <div className="p-4 bg-zinc-900/50 rounded-lg border border-zinc-700">
                  <h3 className="text-white font-medium mb-3 flex items-center gap-2">
                    <Moon className="h-4 w-4 text-blue-400" />
                    Sleep Metrics
                  </h3>
                  <div className="space-y-3">
                    <div className="flex justify-between">
                      <span className="text-zinc-400">Quality Score</span>
                      <span className="text-white font-medium">{wearableData.sleepScore}/100</span>
                    </div>
                    <div className="flex justify-between">
                      <span className="text-zinc-400">Duration</span>
                      <span className="text-white font-medium">{wearableData.sleepDuration}</span>
                    </div>
                    <Progress value={wearableData.sleepScore} className="h-2" />
                  </div>
                </div>

                <div className="p-4 bg-zinc-900/50 rounded-lg border border-zinc-700">
                  <h3 className="text-white font-medium mb-3 flex items-center gap-2">
                    <Heart className="h-4 w-4 text-red-400" />
                    Recovery Metrics
                  </h3>
                  <div className="space-y-3">
                    <div className="flex justify-between">
                      <span className="text-zinc-400">HRV</span>
                      <span className="text-white font-medium">{wearableData.hrv}ms</span>
                    </div>
                    <div className="flex justify-between">
                      <span className="text-zinc-400">Heart Rate</span>
                      <span className="text-white font-medium">{wearableData.heartRate} bpm</span>
                    </div>
                    <div className="flex justify-between">
                      <span className="text-zinc-400">Strain Level</span>
                      <span className="text-white font-medium">{wearableData.strainLevel}</span>
                    </div>
                  </div>
                </div>
              </div>
            )}
          </TabsContent>

          <TabsContent value="predictions" className="space-y-6">
            <div className="p-4 bg-zinc-900/50 rounded-lg border border-zinc-700">
              <h3 className="text-white font-medium mb-4 flex items-center gap-2">
                <TrendingUp className="h-4 w-4 text-green-400" />
                Performance Forecast
              </h3>
              
              {performanceScores && performanceScores.length >= 7 ? (
                <div className="space-y-4">
                  <div className="p-3 bg-green-900/20 rounded border border-green-500/20">
                    <div className="flex items-center gap-2 mb-2">
                      <CheckCircle className="h-4 w-4 text-green-400" />
                      <span className="text-green-300 font-medium">Next 3 Days</span>
                    </div>
                    <p className="text-green-200 text-sm">
                      Based on your current trends, expect performance scores between{' '}
                      {Math.max(0, Math.round(weeklyAvg - 5))} - {Math.min(100, Math.round(weeklyAvg + 5))}.
                      {weeklyChange > 0 && ' Your improving trend suggests scores may lean toward the higher end.'}
                    </p>
                  </div>

                  <div className="p-3 bg-blue-900/20 rounded border border-blue-500/20">
                    <div className="flex items-center gap-2 mb-2">
                      <Clock className="h-4 w-4 text-blue-400" />
                      <span className="text-blue-300 font-medium">Optimization Opportunity</span>
                    </div>
                    <p className="text-blue-200 text-sm">
                      {wearableData?.sleepScore && wearableData.sleepScore < 75 
                        ? 'Focus on sleep quality for the biggest performance gains.'
                        : wearableData?.strainLevel && wearableData.strainLevel > 15
                        ? 'Your body may benefit from active recovery to optimize performance.'
                        : 'You\'re well-positioned for consistent high performance. Consider gradually increasing training load.'
                      }
                    </p>
                  </div>
                </div>
              ) : (
                <div className="text-center py-6">
                  <Brain className="h-8 w-8 text-zinc-500 mx-auto mb-2" />
                  <p className="text-zinc-400 text-sm">
                    Need at least 7 days of data to generate predictions
                  </p>
                </div>
              )}
            </div>
          </TabsContent>
        </Tabs>
      </CardContent>
    </Card>
  );
}