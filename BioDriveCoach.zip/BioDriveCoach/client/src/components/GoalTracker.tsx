import { useState } from "react";
import { useQuery, useMutation, useQueryClient } from "@tanstack/react-query";
import { apiRequest } from "@/lib/queryClient";
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { Badge } from "@/components/ui/badge";
import { Progress } from "@/components/ui/progress";
import { Textarea } from "@/components/ui/textarea";
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select";
import { 
  Target, 
  Plus, 
  CheckCircle, 
  Clock, 
  TrendingUp, 
  Calendar,
  Edit,
  Trash2,
  Flag,
  Zap
} from "lucide-react";
import { format, addDays, differenceInDays, isAfter, isBefore } from "date-fns";
import { useToast } from "@/hooks/use-toast";

interface GoalTrackerProps {
  userId: number;
}

interface Goal {
  id: number;
  title: string;
  description: string;
  category: 'fitness' | 'sleep' | 'nutrition' | 'recovery' | 'performance';
  targetValue: number;
  currentValue: number;
  unit: string;
  deadline: string;
  priority: 'high' | 'medium' | 'low';
  status: 'active' | 'completed' | 'paused';
  milestones: Milestone[];
  createdAt: string;
  updatedAt: string;
}

interface Milestone {
  id: number;
  title: string;
  targetValue: number;
  deadline: string;
  completed: boolean;
  completedAt?: string;
}

const categoryColors = {
  fitness: "bg-purple-500/10 text-purple-400 border-purple-500/20",
  sleep: "bg-blue-500/10 text-blue-400 border-blue-500/20",
  nutrition: "bg-green-500/10 text-green-400 border-green-500/20",
  recovery: "bg-orange-500/10 text-orange-400 border-orange-500/20",
  performance: "bg-red-500/10 text-red-400 border-red-500/20"
};

const priorityColors = {
  high: "bg-red-500/10 text-red-500 border-red-500/20",
  medium: "bg-orange-500/10 text-orange-500 border-orange-500/20",
  low: "bg-blue-500/10 text-blue-500 border-blue-500/20"
};

const goalTemplates = [
  { title: "Improve Sleep Quality", category: "sleep", targetValue: 85, unit: "score", description: "Achieve consistent sleep quality scores above 85" },
  { title: "Increase Daily Steps", category: "fitness", targetValue: 10000, unit: "steps", description: "Walk at least 10,000 steps daily" },
  { title: "Maintain Low Stress", category: "recovery", targetValue: 15, unit: "strain", description: "Keep daily strain below 15 for optimal recovery" },
  { title: "Consistent HRV", category: "performance", targetValue: 40, unit: "ms", description: "Maintain HRV above 40ms for good autonomic balance" },
  { title: "Hydration Goal", category: "nutrition", targetValue: 3, unit: "liters", description: "Drink at least 3 liters of water daily" }
];

export default function GoalTracker({ userId }: GoalTrackerProps) {
  const [isCreating, setIsCreating] = useState(false);
  const [editingGoal, setEditingGoal] = useState<Goal | null>(null);
  const [newGoal, setNewGoal] = useState({
    title: "",
    description: "",
    category: "fitness" as const,
    targetValue: 0,
    unit: "",
    deadline: format(addDays(new Date(), 30), 'yyyy-MM-dd'),
    priority: "medium" as const
  });

  const { toast } = useToast();
  const queryClient = useQueryClient();

  // Mock data for now - would typically come from API
  const mockGoals: Goal[] = [
    {
      id: 1,
      title: "Improve Sleep Quality",
      description: "Achieve consistent sleep scores above 80",
      category: "sleep",
      targetValue: 80,
      currentValue: 73,
      unit: "score",
      deadline: format(addDays(new Date(), 20), 'yyyy-MM-dd'),
      priority: "high",
      status: "active",
      milestones: [
        { id: 1, title: "Week 1: Score 75+", targetValue: 75, deadline: format(addDays(new Date(), 7), 'yyyy-MM-dd'), completed: true, completedAt: format(new Date(), 'yyyy-MM-dd') },
        { id: 2, title: "Week 2: Score 80+", targetValue: 80, deadline: format(addDays(new Date(), 14), 'yyyy-MM-dd'), completed: false }
      ],
      createdAt: format(new Date(), 'yyyy-MM-dd'),
      updatedAt: format(new Date(), 'yyyy-MM-dd')
    },
    {
      id: 2,
      title: "Daily Activity Goal",
      description: "Maintain consistent daily activity levels",
      category: "fitness",
      targetValue: 12,
      currentValue: 8.5,
      unit: "strain",
      deadline: format(addDays(new Date(), 45), 'yyyy-MM-dd'),
      priority: "medium",
      status: "active",
      milestones: [
        { id: 3, title: "Week 1: 8+ strain", targetValue: 8, deadline: format(addDays(new Date(), 7), 'yyyy-MM-dd'), completed: true },
        { id: 4, title: "Week 3: 10+ strain", targetValue: 10, deadline: format(addDays(new Date(), 21), 'yyyy-MM-dd'), completed: false }
      ],
      createdAt: format(new Date(), 'yyyy-MM-dd'),
      updatedAt: format(new Date(), 'yyyy-MM-dd')
    }
  ];

  const calculateProgress = (goal: Goal): number => {
    return Math.min(100, (goal.currentValue / goal.targetValue) * 100);
  };

  const getDaysRemaining = (deadline: string): number => {
    return differenceInDays(new Date(deadline), new Date());
  };

  const getProgressColor = (progress: number): string => {
    if (progress >= 80) return "bg-green-500";
    if (progress >= 60) return "bg-yellow-500";
    if (progress >= 40) return "bg-orange-500";
    return "bg-red-500";
  };

  const handleCreateGoal = () => {
    // Would typically make API call here
    toast({
      title: "Goal Created",
      description: `"${newGoal.title}" has been added to your goals.`,
    });
    setIsCreating(false);
    setNewGoal({
      title: "",
      description: "",
      category: "fitness",
      targetValue: 0,
      unit: "",
      deadline: format(addDays(new Date(), 30), 'yyyy-MM-dd'),
      priority: "medium"
    });
  };

  const handleUpdateProgress = (goalId: number, newValue: number) => {
    // Would typically make API call here
    toast({
      title: "Progress Updated",
      description: "Your goal progress has been updated successfully.",
    });
  };

  const useTemplate = (template: typeof goalTemplates[0]) => {
    setNewGoal({
      title: template.title,
      description: template.description,
      category: template.category as any,
      targetValue: template.targetValue,
      unit: template.unit,
      deadline: format(addDays(new Date(), 30), 'yyyy-MM-dd'),
      priority: "medium"
    });
  };

  return (
    <Card className="bg-gradient-to-br from-emerald-900/20 to-teal-900/20 border-emerald-500/20">
      <CardHeader>
        <div className="flex items-center justify-between">
          <div className="flex items-center gap-2">
            <Target className="h-5 w-5 text-emerald-400" />
            <div>
              <CardTitle className="text-white">Goal Tracker</CardTitle>
              <CardDescription className="text-zinc-400">
                Set and track your health & fitness goals
              </CardDescription>
            </div>
          </div>
          <Button
            onClick={() => setIsCreating(true)}
            className="bg-emerald-600 hover:bg-emerald-700 text-white"
          >
            <Plus className="h-4 w-4 mr-2" />
            New Goal
          </Button>
        </div>
      </CardHeader>

      <CardContent className="space-y-6">
        {/* Active Goals */}
        <div className="space-y-4">
          {mockGoals.filter(goal => goal.status === 'active').map(goal => {
            const progress = calculateProgress(goal);
            const daysRemaining = getDaysRemaining(goal.deadline);
            const isOverdue = daysRemaining < 0;
            const isUrgent = daysRemaining <= 7 && daysRemaining >= 0;

            return (
              <div
                key={goal.id}
                className="p-4 bg-zinc-900/50 rounded-lg border border-zinc-700 space-y-4"
              >
                {/* Goal Header */}
                <div className="flex items-start justify-between">
                  <div className="flex-1">
                    <div className="flex items-center gap-2 mb-2">
                      <h3 className="text-white font-medium">{goal.title}</h3>
                      <Badge 
                        variant="outline" 
                        className={categoryColors[goal.category]}
                      >
                        {goal.category}
                      </Badge>
                      <Badge 
                        variant="outline" 
                        className={priorityColors[goal.priority]}
                      >
                        {goal.priority}
                      </Badge>
                    </div>
                    <p className="text-zinc-400 text-sm mb-2">{goal.description}</p>
                    
                    {/* Progress */}
                    <div className="space-y-2">
                      <div className="flex justify-between text-sm">
                        <span className="text-zinc-300">
                          Progress: {goal.currentValue} / {goal.targetValue} {goal.unit}
                        </span>
                        <span className="text-white font-medium">{progress.toFixed(1)}%</span>
                      </div>
                      <Progress value={progress} className="h-2" />
                    </div>
                  </div>

                  <div className="flex items-center gap-2 ml-4">
                    {isOverdue ? (
                      <Badge variant="outline" className="bg-red-500/10 text-red-400 border-red-500/20">
                        <Clock className="h-3 w-3 mr-1" />
                        Overdue
                      </Badge>
                    ) : isUrgent ? (
                      <Badge variant="outline" className="bg-orange-500/10 text-orange-400 border-orange-500/20">
                        <Clock className="h-3 w-3 mr-1" />
                        {daysRemaining}d left
                      </Badge>
                    ) : (
                      <Badge variant="outline" className="bg-blue-500/10 text-blue-400 border-blue-500/20">
                        <Calendar className="h-3 w-3 mr-1" />
                        {daysRemaining}d left
                      </Badge>
                    )}
                  </div>
                </div>

                {/* Milestones */}
                {goal.milestones.length > 0 && (
                  <div className="space-y-2">
                    <h4 className="text-white text-sm font-medium flex items-center gap-2">
                      <Flag className="h-3 w-3 text-emerald-400" />
                      Milestones
                    </h4>
                    <div className="grid gap-2">
                      {goal.milestones.map(milestone => (
                        <div
                          key={milestone.id}
                          className={`flex items-center gap-3 p-2 rounded ${
                            milestone.completed ? 'bg-green-900/20' : 'bg-zinc-800/50'
                          }`}
                        >
                          <CheckCircle className={`h-4 w-4 ${
                            milestone.completed ? 'text-green-400' : 'text-zinc-500'
                          }`} />
                          <span className={`text-sm ${
                            milestone.completed ? 'text-green-300' : 'text-zinc-300'
                          }`}>
                            {milestone.title}
                          </span>
                          {milestone.completed && (
                            <Badge variant="outline" className="bg-green-500/10 text-green-400 border-green-500/20 text-xs">
                              Complete
                            </Badge>
                          )}
                        </div>
                      ))}
                    </div>
                  </div>
                )}

                {/* Quick Actions */}
                <div className="flex gap-2 pt-2 border-t border-zinc-700">
                  <Input
                    type="number"
                    placeholder="Update value"
                    className="bg-zinc-800 border-zinc-600 text-white text-sm w-32"
                    onKeyPress={(e) => {
                      if (e.key === 'Enter') {
                        const value = parseFloat((e.target as HTMLInputElement).value);
                        if (value) {
                          handleUpdateProgress(goal.id, value);
                          (e.target as HTMLInputElement).value = '';
                        }
                      }
                    }}
                  />
                  <Button size="sm" variant="outline" className="border-zinc-600 text-zinc-300">
                    <Edit className="h-3 w-3" />
                  </Button>
                </div>
              </div>
            );
          })}
        </div>

        {/* Create New Goal Modal */}
        {isCreating && (
          <div className="p-4 bg-zinc-900/80 rounded-lg border border-zinc-600 space-y-4">
            <div className="flex items-center justify-between">
              <h3 className="text-white font-medium">Create New Goal</h3>
              <Button
                onClick={() => setIsCreating(false)}
                variant="outline"
                size="sm"
                className="border-zinc-600 text-zinc-300"
              >
                Cancel
              </Button>
            </div>

            {/* Goal Templates */}
            <div>
              <Label className="text-zinc-300 text-sm">Quick Templates</Label>
              <div className="flex flex-wrap gap-2 mt-2">
                {goalTemplates.map((template, index) => (
                  <Badge
                    key={index}
                    variant="outline"
                    className="cursor-pointer hover:bg-emerald-600/20 text-emerald-300 border-emerald-500/30"
                    onClick={() => useTemplate(template)}
                  >
                    {template.title}
                  </Badge>
                ))}
              </div>
            </div>

            <div className="grid md:grid-cols-2 gap-4">
              <div className="space-y-2">
                <Label className="text-zinc-300">Goal Title</Label>
                <Input
                  value={newGoal.title}
                  onChange={(e) => setNewGoal(prev => ({ ...prev, title: e.target.value }))}
                  placeholder="Enter goal title"
                  className="bg-zinc-800 border-zinc-600 text-white"
                />
              </div>

              <div className="space-y-2">
                <Label className="text-zinc-300">Category</Label>
                <Select value={newGoal.category} onValueChange={(value) => setNewGoal(prev => ({ ...prev, category: value as any }))}>
                  <SelectTrigger className="bg-zinc-800 border-zinc-600 text-white">
                    <SelectValue />
                  </SelectTrigger>
                  <SelectContent>
                    <SelectItem value="fitness">Fitness</SelectItem>
                    <SelectItem value="sleep">Sleep</SelectItem>
                    <SelectItem value="nutrition">Nutrition</SelectItem>
                    <SelectItem value="recovery">Recovery</SelectItem>
                    <SelectItem value="performance">Performance</SelectItem>
                  </SelectContent>
                </Select>
              </div>

              <div className="space-y-2">
                <Label className="text-zinc-300">Target Value</Label>
                <div className="flex gap-2">
                  <Input
                    type="number"
                    value={newGoal.targetValue}
                    onChange={(e) => setNewGoal(prev => ({ ...prev, targetValue: parseFloat(e.target.value) || 0 }))}
                    placeholder="0"
                    className="bg-zinc-800 border-zinc-600 text-white"
                  />
                  <Input
                    value={newGoal.unit}
                    onChange={(e) => setNewGoal(prev => ({ ...prev, unit: e.target.value }))}
                    placeholder="unit"
                    className="bg-zinc-800 border-zinc-600 text-white w-20"
                  />
                </div>
              </div>

              <div className="space-y-2">
                <Label className="text-zinc-300">Deadline</Label>
                <Input
                  type="date"
                  value={newGoal.deadline}
                  onChange={(e) => setNewGoal(prev => ({ ...prev, deadline: e.target.value }))}
                  className="bg-zinc-800 border-zinc-600 text-white"
                />
              </div>

              <div className="md:col-span-2 space-y-2">
                <Label className="text-zinc-300">Description</Label>
                <Textarea
                  value={newGoal.description}
                  onChange={(e) => setNewGoal(prev => ({ ...prev, description: e.target.value }))}
                  placeholder="Describe your goal and why it's important"
                  className="bg-zinc-800 border-zinc-600 text-white"
                  rows={3}
                />
              </div>

              <div className="space-y-2">
                <Label className="text-zinc-300">Priority</Label>
                <Select value={newGoal.priority} onValueChange={(value) => setNewGoal(prev => ({ ...prev, priority: value as any }))}>
                  <SelectTrigger className="bg-zinc-800 border-zinc-600 text-white">
                    <SelectValue />
                  </SelectTrigger>
                  <SelectContent>
                    <SelectItem value="high">High</SelectItem>
                    <SelectItem value="medium">Medium</SelectItem>
                    <SelectItem value="low">Low</SelectItem>
                  </SelectContent>
                </Select>
              </div>
            </div>

            <Button
              onClick={handleCreateGoal}
              disabled={!newGoal.title || !newGoal.targetValue}
              className="w-full bg-emerald-600 hover:bg-emerald-700 text-white"
            >
              <Target className="h-4 w-4 mr-2" />
              Create Goal
            </Button>
          </div>
        )}

        {/* Goal Statistics */}
        <div className="grid grid-cols-2 md:grid-cols-4 gap-4 pt-4 border-t border-zinc-700">
          <div className="text-center">
            <div className="text-2xl font-bold text-white">2</div>
            <div className="text-xs text-zinc-400">Active Goals</div>
          </div>
          <div className="text-center">
            <div className="text-2xl font-bold text-green-400">1</div>
            <div className="text-xs text-zinc-400">Completed</div>
          </div>
          <div className="text-center">
            <div className="text-2xl font-bold text-purple-400">65%</div>
            <div className="text-xs text-zinc-400">Avg Progress</div>
          </div>
          <div className="text-center">
            <div className="text-2xl font-bold text-blue-400">15</div>
            <div className="text-xs text-zinc-400">Days Avg</div>
          </div>
        </div>
      </CardContent>
    </Card>
  );
}