import { Card, CardContent } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { ArrowRight } from "lucide-react";
import { useMutation, useQueryClient } from "@tanstack/react-query";
import { apiRequest } from "@/lib/queryClient";
import { useToast } from "@/hooks/use-toast";

interface MealPlansProps {
  mealPlans: Array<{
    id: number;
    mealType: string;
    name: string;
    description: string;
    calories: number;
    protein: number;
    carbs: number;
    fat: number;
    imageUrl: string;
  }>;
  userId: number;
}

export default function MealPlans({ mealPlans, userId }: MealPlansProps) {
  const queryClient = useQueryClient();
  const { toast } = useToast();

  const generateMealPlanMutation = useMutation({
    mutationFn: (mealType: string) => 
      apiRequest("POST", `/api/meal-plan/${userId}`, { mealType }),
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: [`/api/dashboard/${userId}`] });
      toast({
        title: "Meal Plan Generated",
        description: "Your personalized meal plan has been created based on your biometric data.",
      });
    },
    onError: () => {
      toast({
        title: "Error",
        description: "Failed to generate meal plan. Please try again.",
        variant: "destructive",
      });
    },
  });

  const defaultMeals = [
    {
      mealType: "breakfast",
      name: "Overnight Oats with Berries",
      description: "Overnight oats with berries and almond butter",
      calories: 420,
      protein: 18,
      carbs: 52,
      fat: 16,
      imageUrl: "https://images.unsplash.com/photo-1511690743698-d9d85f2fbf38?ixlib=rb-4.0.3&ixid=MnwxMjA3fDB8MHxwaG90by1wYWdlfHx8fGVufDB8fHx8&auto=format&fit=crop&w=800&h=400",
    },
    {
      mealType: "lunch",
      name: "Quinoa Power Bowl",
      description: "Quinoa power bowl with grilled chicken",
      calories: 580,
      protein: 35,
      carbs: 48,
      fat: 24,
      imageUrl: "https://images.unsplash.com/photo-1512621776951-a57141f2eefd?ixlib=rb-4.0.3&ixid=MnwxMjA3fDB8MHxwaG90by1wYWdlfHx8fGVufDB8fHx8&auto=format&fit=crop&w=800&h=400",
    },
    {
      mealType: "dinner",
      name: "Grilled Salmon with Vegetables",
      description: "Grilled salmon with roasted vegetables",
      calories: 520,
      protein: 38,
      carbs: 28,
      fat: 28,
      imageUrl: "https://images.unsplash.com/photo-1467003909585-2f8a72700288?ixlib=rb-4.0.3&ixid=MnwxMjA3fDB8MHxwaG90by1wYWdlfHx8fGVufDB8fHx8&auto=format&fit=crop&w=800&h=400",
    },
  ];

  const displayMeals = mealPlans.length > 0 ? mealPlans : defaultMeals;

  return (
    <section className="mb-16">
      <div className="flex items-center justify-between mb-8">
        <div className="flex items-center space-x-4">
          <div className="relative">
            <div className="w-8 h-8 rounded-full bg-primary/10 flex items-center justify-center border border-primary/20">
              <div className="w-2 h-2 bg-primary rounded-full pulse-ring"></div>
            </div>
          </div>
          <div>
            <h2 className="text-3xl font-bold text-foreground">AI Meal Plans</h2>
            <p className="text-muted-foreground">Personalized nutrition optimized for your data</p>
          </div>
        </div>
        <Button
          onClick={() => generateMealPlanMutation.mutate("breakfast")}
          disabled={generateMealPlanMutation.isPending}
          className="gradient-primary hover:scale-105 transition-all duration-300"
        >
          {generateMealPlanMutation.isPending ? "Generating..." : "Generate New Plan"}
          <ArrowRight className="ml-2 h-4 w-4" />
        </Button>
      </div>
      
      <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6">
        {displayMeals.map((meal, index) => (
          <Card key={`meal-${index}`} className="card-shadow glass-effect overflow-hidden border border-border hover:border-primary/30 transition-all duration-300 group">
            <div className="relative overflow-hidden">
              <img 
                src={meal.imageUrl} 
                alt={meal.name} 
                className="w-full h-48 object-cover group-hover:scale-105 transition-transform duration-300"
              />
              <div className="absolute inset-0 bg-gradient-to-t from-black/60 via-transparent to-transparent opacity-0 group-hover:opacity-100 transition-opacity duration-300" />
              <div className="absolute top-4 left-4">
                <span className="px-3 py-1 bg-primary/20 text-foreground text-sm font-medium rounded-full border border-primary/30 backdrop-blur-sm capitalize">
                  {meal.mealType}
                </span>
              </div>
            </div>
            <CardContent className="p-6">
              <h3 className="text-lg font-semibold text-foreground mb-2">
                {meal.name}
              </h3>
              <p className="text-muted-foreground text-sm mb-4 line-clamp-2">{meal.description}</p>
              
              <div className="space-y-3">
                <div className="grid grid-cols-2 gap-3">
                  <div className="glass-effect rounded-lg p-3 border border-border/50">
                    <div className="text-xs text-muted-foreground mb-1">Calories</div>
                    <div className="text-sm font-semibold text-foreground">{meal.calories}</div>
                  </div>
                  <div className="glass-effect rounded-lg p-3 border border-border/50">
                    <div className="text-xs text-muted-foreground mb-1">Protein</div>
                    <div className="text-sm font-semibold text-foreground">{meal.protein}g</div>
                  </div>
                </div>
                
                <div className="grid grid-cols-2 gap-3">
                  <div className="glass-effect rounded-lg p-3 border border-border/50">
                    <div className="text-xs text-muted-foreground mb-1">Carbs</div>
                    <div className="text-sm font-semibold text-foreground">{meal.carbs}g</div>
                  </div>
                  <div className="glass-effect rounded-lg p-3 border border-border/50">
                    <div className="text-xs text-muted-foreground mb-1">Fat</div>
                    <div className="text-sm font-semibold text-foreground">{meal.fat}g</div>
                  </div>
                </div>
              </div>
            </CardContent>
          </Card>
        ))}
      </div>
    </section>
  );
}
