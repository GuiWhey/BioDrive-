import { Card, CardContent } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Share2, Download } from "lucide-react";
import { useToast } from "@/hooks/use-toast";

interface ShareableCardProps {
  sleepScore: number;
  recoveryScore: number;
  strainLevel: number;
  performanceScore: number;
  username: string;
}

export default function ShareableCard({ 
  sleepScore, 
  recoveryScore, 
  strainLevel, 
  performanceScore, 
  username 
}: ShareableCardProps) {
  const { toast } = useToast();

  const handleShare = async () => {
    try {
      if (navigator.share) {
        await navigator.share({
          title: "My BioDrive+ Performance",
          text: `Check out my daily performance score: ${performanceScore}/100!`,
          url: window.location.href,
        });
      } else {
        // Fallback to clipboard
        await navigator.clipboard.writeText(
          `My BioDrive+ Performance: Sleep ${sleepScore}, Recovery ${recoveryScore}, Strain ${strainLevel}, Overall ${performanceScore}/100`
        );
        toast({
          title: "Performance card copied!",
          description: "Your performance data has been copied to the clipboard.",
        });
      }
    } catch (error) {
      console.error("Error sharing:", error);
      toast({
        title: "Share failed",
        description: "Could not share your performance card. Please try again.",
        variant: "destructive",
      });
    }
  };

  const handleDownload = () => {
    toast({
      title: "Download started",
      description: "Your performance card is being generated for download.",
    });
  };

  return (
    <section className="mb-16">
      <div className="flex items-center space-x-4 mb-8">
        <div className="relative">
          <div className="w-8 h-8 rounded-full bg-primary/10 flex items-center justify-center border border-primary/20">
            <Share2 className="w-4 h-4 text-primary" />
          </div>
        </div>
        <div>
          <h2 className="text-3xl font-bold text-foreground">Share Your Progress</h2>
          <p className="text-muted-foreground">Show your optimization journey to the world</p>
        </div>
      </div>
      
      <div className="max-w-md mx-auto">
        <Card className="gradient-primary text-white card-shadow">
          <CardContent className="p-6">
            <div className="text-center mb-6">
              <h3 className="text-xl font-semibold mb-2">How Did You Recover?</h3>
              <p className="text-sm opacity-90">{username}'s Daily Performance</p>
            </div>
            
            <div className="grid grid-cols-3 gap-4 mb-6">
              <div className="text-center">
                <div className="text-2xl font-bold">{sleepScore}</div>
                <div className="text-xs opacity-75">Sleep</div>
              </div>
              <div className="text-center">
                <div className="text-2xl font-bold">{recoveryScore}</div>
                <div className="text-xs opacity-75">Recovery</div>
              </div>
              <div className="text-center">
                <div className="text-2xl font-bold">{strainLevel}</div>
                <div className="text-xs opacity-75">Strain</div>
              </div>
            </div>
            
            <div className="text-center mb-6">
              <div className="text-3xl font-bold mb-2">{performanceScore}</div>
              <div className="text-sm opacity-75">Performance Score</div>
            </div>
            
            <div className="flex justify-center space-x-4">
              <Button 
                onClick={handleShare}
                className="bg-white bg-opacity-20 hover:bg-opacity-30 text-white"
                size="sm"
              >
                <Share2 className="mr-2 h-4 w-4" />
                Share
              </Button>
              <Button 
                onClick={handleDownload}
                className="bg-white bg-opacity-20 hover:bg-opacity-30 text-white"
                size="sm"
              >
                <Download className="mr-2 h-4 w-4" />
                Save
              </Button>
            </div>
          </CardContent>
        </Card>
      </div>
    </section>
  );
}
