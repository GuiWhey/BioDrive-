import { useState } from "react";
import { useQuery, useMutation, useQueryClient } from "@tanstack/react-query";
import { apiRequest } from "@/lib/queryClient";
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Badge } from "@/components/ui/badge";
import { Separator } from "@/components/ui/separator";
import { Checkbox } from "@/components/ui/checkbox";
import { Brain, Calendar, CheckCircle, Clock, Target, TrendingUp, Lightbulb, Heart } from "lucide-react";

interface AICoachingProps {
  userId: number;
}

interface CoachingSession {
  id: number;
  personalizedMessage: string;
  keyInsights: string[];
  weeklyFocus: string;
  motivationalNote: string;
  nextCheckIn: string;
  performanceTrend: number;
  createdAt: string;
}

interface CoachingRecommendation {
  id: number;
  priority: 'high' | 'medium' | 'low';
  category: 'sleep' | 'recovery' | 'nutrition' | 'training' | 'stress';
  title: string;
  description: string;
  timeframe: string;
  completed: boolean;
}

const priorityColors = {
  high: "bg-red-500/10 text-red-500 border-red-500/20",
  medium: "bg-orange-500/10 text-orange-500 border-orange-500/20",
  low: "bg-blue-500/10 text-blue-500 border-blue-500/20"
};

const categoryIcons = {
  sleep: Clock,
  recovery: Heart,
  nutrition: Target,
  training: TrendingUp,
  stress: Brain
};

export default function AICoaching({ userId }: AICoachingProps) {
  const [isGenerating, setIsGenerating] = useState(false);
  const queryClient = useQueryClient();

  // Fetch latest coaching session
  const { data: latestSession, isLoading } = useQuery({
    queryKey: ['/api/coaching/latest', userId],
    enabled: !!userId,
  });

  // Generate new coaching session
  const generateCoaching = useMutation({
    mutationFn: () => apiRequest(`/api/coaching/generate/${userId}`, "POST", {}),
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: ['/api/coaching/latest', userId] });
      setIsGenerating(false);
    },
    onError: (error) => {
      console.error("Failed to generate coaching:", error);
      setIsGenerating(false);
    }
  });

  // Update recommendation completion
  const updateRecommendation = useMutation({
    mutationFn: ({ id, completed }: { id: number; completed: boolean }) =>
      apiRequest(`/api/coaching/recommendations/${id}/complete`, "PATCH", { completed }),
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: ['/api/coaching/latest', userId] });
    }
  });

  const handleGenerateCoaching = async () => {
    setIsGenerating(true);
    generateCoaching.mutate();
  };

  const handleToggleRecommendation = (id: number, completed: boolean) => {
    updateRecommendation.mutate({ id, completed });
  };

  if (isLoading) {
    return (
      <Card className="bg-zinc-900/50 border-zinc-800">
        <CardHeader>
          <div className="flex items-center gap-2">
            <Brain className="h-5 w-5 text-purple-400" />
            <CardTitle className="text-white">AI Personal Coach</CardTitle>
          </div>
        </CardHeader>
        <CardContent>
          <div className="animate-pulse space-y-4">
            <div className="h-4 bg-zinc-700 rounded w-3/4"></div>
            <div className="h-4 bg-zinc-700 rounded w-1/2"></div>
            <div className="h-20 bg-zinc-700 rounded"></div>
          </div>
        </CardContent>
      </Card>
    );
  }

  const session = latestSession?.session as CoachingSession | undefined;
  const recommendations = latestSession?.recommendations as CoachingRecommendation[] | undefined;

  return (
    <div className="space-y-6">
      <Card className="bg-gradient-to-br from-purple-900/20 to-blue-900/20 border-purple-500/20">
        <CardHeader>
          <div className="flex items-center justify-between">
            <div className="flex items-center gap-2">
              <Brain className="h-5 w-5 text-purple-400" />
              <div>
                <CardTitle className="text-white">AI Personal Coach</CardTitle>
                <CardDescription className="text-zinc-400">
                  Personalized insights from your biometric data
                </CardDescription>
              </div>
            </div>
            <Button
              onClick={handleGenerateCoaching}
              disabled={isGenerating}
              className="bg-purple-600 hover:bg-purple-700 text-white"
            >
              {isGenerating ? "Analyzing..." : "Get New Insights"}
            </Button>
          </div>
        </CardHeader>

        {session && (
          <CardContent className="space-y-6">
            {/* Personalized Message */}
            <div className="p-4 bg-zinc-900/50 rounded-lg border border-zinc-700">
              <h3 className="text-white font-medium mb-2 flex items-center gap-2">
                <Lightbulb className="h-4 w-4 text-yellow-400" />
                Your Coach's Message
              </h3>
              <p className="text-zinc-300 leading-relaxed">{session.personalizedMessage}</p>
            </div>

            {/* Performance Trend */}
            {session.performanceTrend !== 0 && (
              <div className="flex items-center gap-2 text-sm">
                <TrendingUp className={`h-4 w-4 ${session.performanceTrend > 0 ? 'text-green-400' : 'text-red-400'}`} />
                <span className="text-zinc-300">
                  Performance trend: 
                  <span className={`ml-1 font-medium ${session.performanceTrend > 0 ? 'text-green-400' : 'text-red-400'}`}>
                    {session.performanceTrend > 0 ? '+' : ''}{session.performanceTrend.toFixed(1)} points
                  </span>
                </span>
              </div>
            )}

            {/* Key Insights */}
            <div>
              <h3 className="text-white font-medium mb-3 flex items-center gap-2">
                <Target className="h-4 w-4 text-green-400" />
                Key Insights
              </h3>
              <div className="grid gap-2">
                {session.keyInsights.map((insight, index) => (
                  <div key={index} className="flex items-start gap-2 text-zinc-300 text-sm">
                    <div className="w-1.5 h-1.5 bg-green-400 rounded-full mt-2 flex-shrink-0" />
                    <span>{insight}</span>
                  </div>
                ))}
              </div>
            </div>

            <Separator className="bg-zinc-700" />

            {/* Weekly Focus */}
            <div className="p-4 bg-blue-900/20 rounded-lg border border-blue-500/20">
              <h3 className="text-white font-medium mb-2 flex items-center gap-2">
                <Calendar className="h-4 w-4 text-blue-400" />
                This Week's Focus
              </h3>
              <p className="text-blue-300">{session.weeklyFocus}</p>
            </div>

            {/* Actionable Recommendations */}
            {recommendations && recommendations.length > 0 && (
              <div>
                <h3 className="text-white font-medium mb-3 flex items-center gap-2">
                  <CheckCircle className="h-4 w-4 text-purple-400" />
                  Action Plan
                </h3>
                <div className="space-y-3">
                  {recommendations.map((rec) => {
                    const IconComponent = categoryIcons[rec.category];
                    return (
                      <div
                        key={rec.id}
                        className="p-4 bg-zinc-900/50 rounded-lg border border-zinc-700 transition-all hover:border-zinc-600"
                      >
                        <div className="flex items-start gap-3">
                          <Checkbox
                            checked={rec.completed}
                            onCheckedChange={(checked) => 
                              handleToggleRecommendation(rec.id, !!checked)
                            }
                            className="mt-0.5"
                          />
                          <div className="flex-1 space-y-2">
                            <div className="flex items-center gap-2 flex-wrap">
                              <h4 className={`font-medium ${rec.completed ? 'text-zinc-500 line-through' : 'text-white'}`}>
                                {rec.title}
                              </h4>
                              <Badge 
                                variant="outline" 
                                className={`text-xs ${priorityColors[rec.priority]}`}
                              >
                                {rec.priority}
                              </Badge>
                              <div className="flex items-center gap-1 text-xs text-zinc-400">
                                <IconComponent className="h-3 w-3" />
                                <span>{rec.category}</span>
                              </div>
                            </div>
                            <p className={`text-sm ${rec.completed ? 'text-zinc-500' : 'text-zinc-300'}`}>
                              {rec.description}
                            </p>
                            <div className="flex items-center gap-2 text-xs text-zinc-400">
                              <Clock className="h-3 w-3" />
                              <span>{rec.timeframe}</span>
                            </div>
                          </div>
                        </div>
                      </div>
                    );
                  })}
                </div>
              </div>
            )}

            {/* Motivational Note */}
            <div className="p-4 bg-gradient-to-r from-green-900/20 to-blue-900/20 rounded-lg border border-green-500/20">
              <h3 className="text-white font-medium mb-2 flex items-center gap-2">
                <Heart className="h-4 w-4 text-green-400" />
                Motivation
              </h3>
              <p className="text-green-300">{session.motivationalNote}</p>
            </div>

            {/* Next Check-in */}
            <div className="text-center p-3 bg-zinc-800/50 rounded-lg">
              <p className="text-zinc-400 text-sm">
                Next check-in: <span className="text-white font-medium">{session.nextCheckIn}</span>
              </p>
            </div>
          </CardContent>
        )}

        {!session && (
          <CardContent>
            <div className="text-center py-8">
              <Brain className="h-12 w-12 text-purple-400 mx-auto mb-4" />
              <h3 className="text-white font-medium mb-2">Get Your First AI Coaching Session</h3>
              <p className="text-zinc-400 mb-4">
                Analyze your biometric data to receive personalized insights and recommendations.
              </p>
              <Button
                onClick={handleGenerateCoaching}
                disabled={isGenerating}
                className="bg-purple-600 hover:bg-purple-700 text-white"
              >
                {isGenerating ? "Analyzing Your Data..." : "Start Coaching"}
              </Button>
            </div>
          </CardContent>
        )}
      </Card>
    </div>
  );
}