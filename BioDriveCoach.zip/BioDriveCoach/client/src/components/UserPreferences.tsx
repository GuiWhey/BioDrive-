import { useState } from "react";
import { useQuery, useMutation, useQueryClient } from "@tanstack/react-query";
import { apiRequest } from "@/lib/queryClient";
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { Textarea } from "@/components/ui/textarea";
import { Badge } from "@/components/ui/badge";
import { X, Plus, Settings, Target, Clock, Utensils, Dumbbell } from "lucide-react";
import { useToast } from "@/hooks/use-toast";

interface UserPreferencesProps {
  userId: number;
}

interface UserPreferences {
  id: number;
  userId: number;
  goals: string[];
  currentChallenges: string[];
  workoutTypes: string[];
  dietaryRestrictions: string[];
  sleepSchedule: string;
  updatedAt: string;
}

const workoutTypeOptions = [
  "Strength Training", "Cardio", "HIIT", "Yoga", "Pilates", 
  "Running", "Cycling", "Swimming", "CrossFit", "Rock Climbing"
];

const dietaryOptions = [
  "Vegetarian", "Vegan", "Keto", "Paleo", "Gluten-Free", 
  "Dairy-Free", "Low-Carb", "Mediterranean", "Intermittent Fasting"
];

const goalSuggestions = [
  "Improve sleep quality", "Increase energy levels", "Build muscle mass",
  "Lose weight", "Reduce stress", "Improve cardiovascular health",
  "Better recovery", "Optimize performance", "Balance work-life"
];

const challengeSuggestions = [
  "Poor sleep patterns", "High stress levels", "Inconsistent workouts",
  "Difficulty waking up", "Low motivation", "Time management",
  "Diet consistency", "Recovery issues", "Energy crashes"
];

export default function UserPreferences({ userId }: UserPreferencesProps) {
  const [isEditing, setIsEditing] = useState(false);
  const [newGoal, setNewGoal] = useState("");
  const [newChallenge, setNewChallenge] = useState("");
  const { toast } = useToast();
  const queryClient = useQueryClient();

  const { data: preferences, isLoading } = useQuery<UserPreferences>({
    queryKey: ['/api/preferences', userId],
    enabled: !!userId,
  });

  const [formData, setFormData] = useState<Partial<UserPreferences>>({
    goals: preferences?.goals || [],
    currentChallenges: preferences?.currentChallenges || [],
    workoutTypes: preferences?.workoutTypes || [],
    dietaryRestrictions: preferences?.dietaryRestrictions || [],
    sleepSchedule: preferences?.sleepSchedule || "",
  });

  const updatePreferences = useMutation({
    mutationFn: (data: Partial<UserPreferences>) =>
      apiRequest(`/api/preferences/${userId}`, "POST", data),
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: ['/api/preferences', userId] });
      queryClient.invalidateQueries({ queryKey: ['/api/coaching/latest', userId] });
      setIsEditing(false);
      toast({
        title: "Preferences Updated",
        description: "Your coaching preferences have been saved successfully.",
      });
    },
    onError: () => {
      toast({
        title: "Error",
        description: "Failed to update preferences. Please try again.",
        variant: "destructive",
      });
    }
  });

  const handleSave = () => {
    updatePreferences.mutate(formData);
  };

  const addItem = (field: keyof UserPreferences, value: string) => {
    if (value.trim() && formData[field] && !formData[field]!.includes(value)) {
      setFormData(prev => ({
        ...prev,
        [field]: [...(prev[field] as string[]), value.trim()]
      }));
    }
  };

  const removeItem = (field: keyof UserPreferences, value: string) => {
    setFormData(prev => ({
      ...prev,
      [field]: (prev[field] as string[]).filter(item => item !== value)
    }));
  };

  const toggleWorkoutType = (type: string) => {
    const current = formData.workoutTypes || [];
    if (current.includes(type)) {
      removeItem('workoutTypes', type);
    } else {
      addItem('workoutTypes', type);
    }
  };

  const toggleDietaryRestriction = (restriction: string) => {
    const current = formData.dietaryRestrictions || [];
    if (current.includes(restriction)) {
      removeItem('dietaryRestrictions', restriction);
    } else {
      addItem('dietaryRestrictions', restriction);
    }
  };

  if (isLoading) {
    return (
      <Card className="bg-zinc-900/50 border-zinc-800">
        <CardHeader>
          <div className="flex items-center gap-2">
            <Settings className="h-5 w-5 text-blue-400" />
            <CardTitle className="text-white">Coaching Preferences</CardTitle>
          </div>
        </CardHeader>
        <CardContent>
          <div className="animate-pulse space-y-4">
            <div className="h-4 bg-zinc-700 rounded w-3/4"></div>
            <div className="h-4 bg-zinc-700 rounded w-1/2"></div>
            <div className="h-20 bg-zinc-700 rounded"></div>
          </div>
        </CardContent>
      </Card>
    );
  }

  return (
    <Card className="bg-gradient-to-br from-blue-900/20 to-indigo-900/20 border-blue-500/20">
      <CardHeader>
        <div className="flex items-center justify-between">
          <div className="flex items-center gap-2">
            <Settings className="h-5 w-5 text-blue-400" />
            <div>
              <CardTitle className="text-white">Coaching Preferences</CardTitle>
              <CardDescription className="text-zinc-400">
                Customize your AI coaching experience
              </CardDescription>
            </div>
          </div>
          <Button
            onClick={() => setIsEditing(!isEditing)}
            variant={isEditing ? "secondary" : "outline"}
            className="text-white border-blue-500/30 hover:bg-blue-600/20"
          >
            {isEditing ? "Cancel" : "Edit"}
          </Button>
        </div>
      </CardHeader>

      <CardContent className="space-y-6">
        {/* Goals Section */}
        <div>
          <div className="flex items-center gap-2 mb-3">
            <Target className="h-4 w-4 text-green-400" />
            <Label className="text-white font-medium">Health & Fitness Goals</Label>
          </div>
          
          {isEditing ? (
            <div className="space-y-3">
              <div className="flex gap-2">
                <Input
                  value={newGoal}
                  onChange={(e) => setNewGoal(e.target.value)}
                  placeholder="Add a new goal..."
                  className="bg-zinc-800 border-zinc-600 text-white"
                  onKeyPress={(e) => {
                    if (e.key === 'Enter') {
                      addItem('goals', newGoal);
                      setNewGoal("");
                    }
                  }}
                />
                <Button
                  onClick={() => {
                    addItem('goals', newGoal);
                    setNewGoal("");
                  }}
                  size="sm"
                  className="bg-green-600 hover:bg-green-700"
                >
                  <Plus className="h-4 w-4" />
                </Button>
              </div>
              
              <div className="flex flex-wrap gap-2">
                {goalSuggestions.map(goal => (
                  <Badge
                    key={goal}
                    variant="outline"
                    className={`cursor-pointer text-xs ${
                      formData.goals?.includes(goal)
                        ? 'bg-green-600/20 text-green-300 border-green-500/30'
                        : 'text-zinc-400 border-zinc-600 hover:bg-green-600/10'
                    }`}
                    onClick={() => addItem('goals', goal)}
                  >
                    {goal}
                  </Badge>
                ))}
              </div>
            </div>
          ) : null}
          
          <div className="flex flex-wrap gap-2 mt-2">
            {(isEditing ? formData.goals : preferences?.goals)?.map(goal => (
              <Badge
                key={goal}
                className="bg-green-600/20 text-green-300 border-green-500/30"
              >
                {goal}
                {isEditing && (
                  <X
                    className="h-3 w-3 ml-1 cursor-pointer"
                    onClick={() => removeItem('goals', goal)}
                  />
                )}
              </Badge>
            )) || <span className="text-zinc-500 text-sm">No goals set</span>}
          </div>
        </div>

        {/* Current Challenges */}
        <div>
          <div className="flex items-center gap-2 mb-3">
            <Target className="h-4 w-4 text-orange-400" />
            <Label className="text-white font-medium">Current Challenges</Label>
          </div>
          
          {isEditing ? (
            <div className="space-y-3">
              <div className="flex gap-2">
                <Input
                  value={newChallenge}
                  onChange={(e) => setNewChallenge(e.target.value)}
                  placeholder="Add a challenge..."
                  className="bg-zinc-800 border-zinc-600 text-white"
                  onKeyPress={(e) => {
                    if (e.key === 'Enter') {
                      addItem('currentChallenges', newChallenge);
                      setNewChallenge("");
                    }
                  }}
                />
                <Button
                  onClick={() => {
                    addItem('currentChallenges', newChallenge);
                    setNewChallenge("");
                  }}
                  size="sm"
                  className="bg-orange-600 hover:bg-orange-700"
                >
                  <Plus className="h-4 w-4" />
                </Button>
              </div>
              
              <div className="flex flex-wrap gap-2">
                {challengeSuggestions.map(challenge => (
                  <Badge
                    key={challenge}
                    variant="outline"
                    className={`cursor-pointer text-xs ${
                      formData.currentChallenges?.includes(challenge)
                        ? 'bg-orange-600/20 text-orange-300 border-orange-500/30'
                        : 'text-zinc-400 border-zinc-600 hover:bg-orange-600/10'
                    }`}
                    onClick={() => addItem('currentChallenges', challenge)}
                  >
                    {challenge}
                  </Badge>
                ))}
              </div>
            </div>
          ) : null}
          
          <div className="flex flex-wrap gap-2 mt-2">
            {(isEditing ? formData.currentChallenges : preferences?.currentChallenges)?.map(challenge => (
              <Badge
                key={challenge}
                className="bg-orange-600/20 text-orange-300 border-orange-500/30"
              >
                {challenge}
                {isEditing && (
                  <X
                    className="h-3 w-3 ml-1 cursor-pointer"
                    onClick={() => removeItem('currentChallenges', challenge)}
                  />
                )}
              </Badge>
            )) || <span className="text-zinc-500 text-sm">No challenges identified</span>}
          </div>
        </div>

        {/* Workout Preferences */}
        <div>
          <div className="flex items-center gap-2 mb-3">
            <Dumbbell className="h-4 w-4 text-purple-400" />
            <Label className="text-white font-medium">Preferred Workout Types</Label>
          </div>
          
          {isEditing ? (
            <div className="flex flex-wrap gap-2">
              {workoutTypeOptions.map(type => (
                <Badge
                  key={type}
                  variant="outline"
                  className={`cursor-pointer ${
                    formData.workoutTypes?.includes(type)
                      ? 'bg-purple-600/20 text-purple-300 border-purple-500/30'
                      : 'text-zinc-400 border-zinc-600 hover:bg-purple-600/10'
                  }`}
                  onClick={() => toggleWorkoutType(type)}
                >
                  {type}
                </Badge>
              ))}
            </div>
          ) : (
            <div className="flex flex-wrap gap-2">
              {preferences?.workoutTypes?.map(type => (
                <Badge
                  key={type}
                  className="bg-purple-600/20 text-purple-300 border-purple-500/30"
                >
                  {type}
                </Badge>
              )) || <span className="text-zinc-500 text-sm">No workout preferences set</span>}
            </div>
          )}
        </div>

        {/* Dietary Restrictions */}
        <div>
          <div className="flex items-center gap-2 mb-3">
            <Utensils className="h-4 w-4 text-blue-400" />
            <Label className="text-white font-medium">Dietary Preferences</Label>
          </div>
          
          {isEditing ? (
            <div className="flex flex-wrap gap-2">
              {dietaryOptions.map(restriction => (
                <Badge
                  key={restriction}
                  variant="outline"
                  className={`cursor-pointer ${
                    formData.dietaryRestrictions?.includes(restriction)
                      ? 'bg-blue-600/20 text-blue-300 border-blue-500/30'
                      : 'text-zinc-400 border-zinc-600 hover:bg-blue-600/10'
                  }`}
                  onClick={() => toggleDietaryRestriction(restriction)}
                >
                  {restriction}
                </Badge>
              ))}
            </div>
          ) : (
            <div className="flex flex-wrap gap-2">
              {preferences?.dietaryRestrictions?.map(restriction => (
                <Badge
                  key={restriction}
                  className="bg-blue-600/20 text-blue-300 border-blue-500/30"
                >
                  {restriction}
                </Badge>
              )) || <span className="text-zinc-500 text-sm">No dietary restrictions</span>}
            </div>
          )}
        </div>

        {/* Sleep Schedule */}
        <div>
          <div className="flex items-center gap-2 mb-3">
            <Clock className="h-4 w-4 text-indigo-400" />
            <Label className="text-white font-medium">Sleep Schedule</Label>
          </div>
          
          {isEditing ? (
            <Textarea
              value={formData.sleepSchedule}
              onChange={(e) => setFormData(prev => ({ ...prev, sleepSchedule: e.target.value }))}
              placeholder="Describe your ideal sleep schedule (e.g., 10 PM - 6 AM, shift work, etc.)"
              className="bg-zinc-800 border-zinc-600 text-white"
              rows={3}
            />
          ) : (
            <p className="text-zinc-300 bg-zinc-800/50 p-3 rounded-lg">
              {preferences?.sleepSchedule || "No sleep schedule specified"}
            </p>
          )}
        </div>

        {isEditing && (
          <div className="flex gap-3 pt-4">
            <Button
              onClick={handleSave}
              disabled={updatePreferences.isPending}
              className="bg-blue-600 hover:bg-blue-700 text-white"
            >
              {updatePreferences.isPending ? "Saving..." : "Save Preferences"}
            </Button>
            <Button
              onClick={() => {
                setIsEditing(false);
                setFormData({
                  goals: preferences?.goals || [],
                  currentChallenges: preferences?.currentChallenges || [],
                  workoutTypes: preferences?.workoutTypes || [],
                  dietaryRestrictions: preferences?.dietaryRestrictions || [],
                  sleepSchedule: preferences?.sleepSchedule || "",
                });
              }}
              variant="outline"
              className="border-zinc-600 text-zinc-300 hover:bg-zinc-700"
            >
              Cancel
            </Button>
          </div>
        )}
      </CardContent>
    </Card>
  );
}