import { useQuery } from "@tanstack/react-query";
import { useState } from "react";
import Header from "@/components/Header";
import TodaysProtocol from "@/components/TodaysProtocol";
import MealPlans from "@/components/MealPlans";
import ProgressVisualizer from "@/components/ProgressVisualizer";
import WearableDevices from "@/components/WearableDevices";
import SubscriptionTiers from "@/components/SubscriptionTiers";
import ShareableCard from "@/components/ShareableCard";
import AICoaching from "@/components/AICoaching";
import UserPreferences from "@/components/UserPreferences";
import CoachingHistory from "@/components/CoachingHistory";
import SmartInsights from "@/components/SmartInsights";
import GoalTracker from "@/components/GoalTracker";
import { DashboardData } from "@/lib/types";

export default function Dashboard() {
  const [userId] = useState(1); // Demo user ID

  const { data: dashboardData, isLoading } = useQuery<DashboardData>({
    queryKey: [`/api/dashboard/${userId}`],
    refetchInterval: 5000, // Refetch every 5 seconds for testing
    staleTime: 0, // Always consider data stale
    cacheTime: 0, // Don't cache data
  });

  if (isLoading) {
    return (
      <div className="min-h-screen bg-background text-foreground">
        <Header />
        <div className="flex items-center justify-center h-96">
          <div className="relative">
            <div className="w-32 h-32 rounded-full border-2 border-border"></div>
            <div className="absolute inset-0 w-32 h-32 rounded-full border-t-2 border-primary animate-spin"></div>
            <div className="absolute inset-4 w-24 h-24 rounded-full border border-secondary/20"></div>
            <div className="absolute inset-8 w-16 h-16 rounded-full bg-primary/10 flex items-center justify-center">
              <div className="w-2 h-2 bg-secondary rounded-full pulse-ring"></div>
            </div>
          </div>
        </div>
      </div>
    );
  }

  return (
    <div className="min-h-screen bg-background text-foreground">
      <Header />
      
      {/* Hero Section */}
      <section className="hero-gradient text-white py-16 relative overflow-hidden">
        <div className="absolute inset-0 opacity-10">
          <div className="w-96 h-96 radar-sweep absolute top-1/2 left-1/2 transform -translate-x-1/2 -translate-y-1/2"></div>
        </div>
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 relative z-10">
          <div className="text-center">
            <div className="inline-flex items-center px-4 py-2 rounded-full glass-effect mb-6 border border-secondary/20">
              <div className="w-2 h-2 bg-secondary rounded-full mr-2 pulse-ring"></div>
              <span className="text-sm font-medium">Live Optimization Active</span>
            </div>
            <h1 className="text-5xl md:text-7xl font-bold mb-6 bg-gradient-to-r from-white via-purple-200 to-secondary bg-clip-text text-transparent">
              Live like your data knows you
            </h1>
            <p className="text-xl md:text-2xl mb-12 opacity-90 max-w-3xl mx-auto">
              AI that turns WHOOP + Apple Watch data into precision nutrition, recovery protocols, and daily performance optimization
            </p>
            <div className="flex flex-col sm:flex-row gap-6 justify-center">
              <button className="gradient-primary px-10 py-4 rounded-xl font-semibold text-lg hover:scale-105 transition-all duration-300 neon-glow">
                Start Optimization
              </button>
              <button className="glass-effect px-10 py-4 rounded-xl font-semibold text-lg hover:bg-white/10 transition-all duration-300 border border-white/20">
                View Live Demo
              </button>
            </div>
          </div>
        </div>
      </section>

      {/* Main Dashboard */}
      <main className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-12 -mt-8 relative z-20">
        <div className="grid lg:grid-cols-3 gap-6 mb-8">
          <div className="lg:col-span-2">
            <AICoaching userId={userId} />
          </div>
          <div>
            <SmartInsights userId={userId} />
          </div>
        </div>
        
        <div className="grid lg:grid-cols-2 gap-6 mb-8">
          <UserPreferences userId={userId} />
          <CoachingHistory userId={userId} />
        </div>
        
        <GoalTracker userId={userId} />
        
        <TodaysProtocol
          wearableData={dashboardData?.wearableData}
          recoveryProtocols={dashboardData?.recoveryProtocols || []}
          userId={userId}
        />
        
        <MealPlans
          mealPlans={dashboardData?.mealPlans || []}
          userId={userId}
        />
        
        <ProgressVisualizer
          performanceScores={dashboardData?.performanceScores || []}
          wearableData={dashboardData?.wearableData}
        />
        
        <WearableDevices userId={userId} />
        
        <SubscriptionTiers currentTier={dashboardData?.user?.subscriptionTier || "basic"} />
        
        <ShareableCard
          sleepScore={dashboardData?.wearableData?.sleepScore || 70}
          recoveryScore={92}
          strainLevel={parseFloat(dashboardData?.wearableData?.strainLevel || "10")}
          performanceScore={dashboardData?.performanceScores?.[0]?.overallScore || 84}
          username={dashboardData?.user?.username || "User"}
        />
      </main>

      {/* Footer */}
      <footer className="bg-slate-800 text-white py-12">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
          <div className="grid grid-cols-1 md:grid-cols-4 gap-8">
            <div>
              <div className="flex items-center mb-4">
                <i className="fas fa-chart-line text-primary text-xl mr-2"></i>
                <span className="text-xl font-bold">BioDrive+</span>
              </div>
              <p className="text-gray-400">
                AI-powered health optimization that turns your wearable data into actionable insights.
              </p>
            </div>
            <div>
              <h4 className="font-semibold mb-4">Product</h4>
              <ul className="space-y-2 text-gray-400">
                <li><a href="#" className="hover:text-white transition-colors">Features</a></li>
                <li><a href="#" className="hover:text-white transition-colors">Pricing</a></li>
                <li><a href="#" className="hover:text-white transition-colors">Integrations</a></li>
                <li><a href="#" className="hover:text-white transition-colors">API</a></li>
              </ul>
            </div>
            <div>
              <h4 className="font-semibold mb-4">Company</h4>
              <ul className="space-y-2 text-gray-400">
                <li><a href="#" className="hover:text-white transition-colors">About</a></li>
                <li><a href="#" className="hover:text-white transition-colors">Blog</a></li>
                <li><a href="#" className="hover:text-white transition-colors">Careers</a></li>
                <li><a href="#" className="hover:text-white transition-colors">Contact</a></li>
              </ul>
            </div>
            <div>
              <h4 className="font-semibold mb-4">Support</h4>
              <ul className="space-y-2 text-gray-400">
                <li><a href="#" className="hover:text-white transition-colors">Help Center</a></li>
                <li><a href="#" className="hover:text-white transition-colors">Privacy</a></li>
                <li><a href="#" className="hover:text-white transition-colors">Terms</a></li>
                <li><a href="#" className="hover:text-white transition-colors">Status</a></li>
              </ul>
            </div>
          </div>
          <div className="border-t border-gray-700 mt-8 pt-8 text-center text-gray-400">
            <p>&copy; 2024 BioDrive+. All rights reserved.</p>
          </div>
        </div>
      </footer>
    </div>
  );
}
