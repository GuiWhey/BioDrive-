import { useEffect } from 'react';
import { useLocation } from 'wouter';
import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/card';
import { CheckCircle, XCircle, Loader2 } from 'lucide-react';

export default function AuthCallback() {
  const [, setLocation] = useLocation();

  useEffect(() => {
    // Get URL parameters
    const urlParams = new URLSearchParams(window.location.search);
    const code = urlParams.get('code');
    const state = urlParams.get('state');
    const error = urlParams.get('error');

    if (error) {
      // Handle OAuth error
      console.error('OAuth error:', error);
      setTimeout(() => {
        setLocation('/dashboard');
      }, 3000);
      return;
    }

    if (code && state) {
      // OAuth success - the backend will handle the token exchange
      // Return to the stored URL or dashboard
      const returnUrl = localStorage.getItem('biodrive_return_url') || '/dashboard';
      localStorage.removeItem('biodrive_return_url');
      
      setTimeout(() => {
        setLocation(returnUrl);
      }, 2000);
    } else {
      // No code or state - redirect to dashboard
      setTimeout(() => {
        setLocation('/dashboard');
      }, 2000);
    }
  }, [setLocation]);

  // Determine status based on URL parameters
  const urlParams = new URLSearchParams(window.location.search);
  const error = urlParams.get('error');
  const code = urlParams.get('code');

  return (
    <div className="min-h-screen bg-background flex items-center justify-center p-4">
      <Card className="w-full max-w-md glass-effect border-border/50">
        <CardHeader className="text-center">
          <CardTitle className="text-foreground">Authentication Status</CardTitle>
        </CardHeader>
        <CardContent className="text-center space-y-4">
          {error ? (
            <>
              <XCircle className="w-12 h-12 text-destructive mx-auto" />
              <div>
                <h3 className="text-lg font-semibold text-foreground">Authentication Failed</h3>
                <p className="text-muted-foreground">
                  There was an error connecting your device. Redirecting back to dashboard...
                </p>
              </div>
            </>
          ) : code ? (
            <>
              <CheckCircle className="w-12 h-12 text-secondary mx-auto" />
              <div>
                <h3 className="text-lg font-semibold text-foreground">Authentication Successful</h3>
                <p className="text-muted-foreground">
                  Your device has been connected successfully. Redirecting back to dashboard...
                </p>
              </div>
            </>
          ) : (
            <>
              <Loader2 className="w-12 h-12 text-primary mx-auto animate-spin" />
              <div>
                <h3 className="text-lg font-semibold text-foreground">Processing...</h3>
                <p className="text-muted-foreground">
                  Processing authentication. Please wait...
                </p>
              </div>
            </>
          )}
        </CardContent>
      </Card>
    </div>
  );
}