export interface DashboardData {
  user: {
    id: number;
    username: string;
    email: string;
    subscriptionTier: string;
    createdAt: string;
  };
  wearableData?: {
    id: number;
    deviceType: string;
    sleepScore: number;
    sleepDuration: string;
    strainLevel: string;
    hrv: number;
    heartRate: number;
    recordedAt: string;
  };
  mealPlans: Array<{
    id: number;
    mealType: string;
    name: string;
    description: string;
    calories: number;
    protein: number;
    carbs: number;
    fat: number;
    imageUrl: string;
    createdAt: string;
  }>;
  recoveryProtocols: Array<{
    id: number;
    type: string;
    name: string;
    description: string;
    duration: string;
    createdAt: string;
  }>;
  performanceScores: Array<{
    id: number;
    sleepScore: number;
    recoveryScore: number;
    strainLevel: string;
    overallScore: number;
    date: string;
  }>;
}

export interface DeviceStatus {
  whoop: {
    connected: boolean;
    lastSync: string;
    battery?: number;
  };
  apple_watch: {
    connected: boolean;
    lastSync: string;
    battery?: number;
  };
}
