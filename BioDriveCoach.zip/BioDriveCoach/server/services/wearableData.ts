import { type InsertWearableData, type WearableData } from "@shared/schema";

export interface MockWearableData {
  sleepScore: number;
  sleepDuration: string;
  strainLevel: number;
  hrv: number;
  heartRate: number;
  deviceType: 'whoop' | 'apple_watch';
}

export function generateMockWearableData(): MockWearableData {
  // Generate realistic mock data with some variability
  const baseTime = new Date();
  const timeVariation = Math.random() * 2 - 1; // -1 to 1 hours
  
  // Sleep score typically ranges from 60-95
  const sleepScore = Math.floor(Math.random() * 35) + 60;
  
  // Sleep duration typically 6-9 hours
  const sleepHours = Math.floor(Math.random() * 3) + 6;
  const sleepMinutes = Math.floor(Math.random() * 60);
  const sleepDuration = `${sleepHours}h ${sleepMinutes}m`;
  
  // Strain level typically 8-18
  const strainLevel = Math.round((Math.random() * 10 + 8) * 10) / 10;
  
  // HRV typically 20-80ms
  const hrv = Math.floor(Math.random() * 60) + 20;
  
  // Resting heart rate typically 45-75 bpm
  const heartRate = Math.floor(Math.random() * 30) + 45;
  
  // Randomly choose device type
  const deviceType = Math.random() > 0.5 ? 'whoop' : 'apple_watch';
  
  return {
    sleepScore,
    sleepDuration,
    strainLevel,
    hrv,
    heartRate,
    deviceType,
  };
}

export function simulateWearableDataUpdate(userId: number): InsertWearableData {
  const mockData = generateMockWearableData();
  
  return {
    userId,
    deviceType: mockData.deviceType,
    sleepScore: mockData.sleepScore,
    sleepDuration: mockData.sleepDuration,
    strainLevel: mockData.strainLevel.toString(),
    hrv: mockData.hrv,
    heartRate: mockData.heartRate,
  };
}

export function getDeviceConnectionStatus(deviceType: 'whoop' | 'apple_watch'): {
  connected: boolean;
  lastSync: string;
  battery?: number;
} {
  // Simulate connection status
  const connected = Math.random() > 0.1; // 90% chance of being connected
  const lastSyncMinutes = Math.floor(Math.random() * 10) + 1;
  const battery = deviceType === 'whoop' ? Math.floor(Math.random() * 40) + 60 : undefined;
  
  return {
    connected,
    lastSync: `${lastSyncMinutes} min ago`,
    battery,
  };
}
