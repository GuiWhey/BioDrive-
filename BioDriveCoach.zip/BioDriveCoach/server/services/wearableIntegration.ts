import { Request, Response } from 'express';

// WHOOP API Configuration
const WHOOP_CONFIG = {
  authorizationURL: 'https://api.prod.whoop.com/oauth/oauth2/auth',
  tokenURL: 'https://api.prod.whoop.com/oauth/oauth2/token',
  baseURL: 'https://api.prod.whoop.com/developer/v1',
  clientId: process.env.WHOOP_CLIENT_ID,
  clientSecret: process.env.WHOOP_CLIENT_SECRET,
  redirectUri: process.env.WHOOP_REDIRECT_URI || `https://${process.env.REPL_SLUG || 'biodrive'}.${process.env.REPL_OWNER || 'user'}.repl.co/api/auth/whoop/callback`,
  scopes: [
    'offline',
    'read:profile',
    'read:recovery',
    'read:cycles',
    'read:sleep',
    'read:workout',
    'read:body_measurement'
  ]
};

// Terra API Configuration for Apple HealthKit
const TERRA_CONFIG = {
  baseURL: 'https://api.tryterra.co/v2',
  apiKey: process.env.TERRA_API_KEY,
  devId: process.env.TERRA_DEV_ID,
  secret: process.env.TERRA_SECRET
};

export interface WearableTokens {
  accessToken: string;
  refreshToken: string;
  expiresAt: Date;
  provider: 'whoop' | 'apple_health';
  userId: number;
}

export interface WearableData {
  sleepScore?: number;
  sleepDuration?: string;
  strainLevel?: number;
  hrv?: number;
  heartRate?: number;
  recoveryScore?: number;
  deviceType: 'whoop' | 'apple_watch';
  recordedAt: Date;
}

// WHOOP API Integration
export class WHOOPIntegration {
  
  static generateAuthURL(userId: number): string {
    if (!WHOOP_CONFIG.clientId || !WHOOP_CONFIG.redirectUri) {
      throw new Error('WHOOP credentials not configured');
    }

    // Generate a secure 8-character state parameter as required by WHOOP
    const state = Math.random().toString(36).substring(2, 10).toUpperCase();
    
    // Store the mapping of state to userId for callback processing
    // In production, you'd want to use Redis or a database for this
    (global as any).stateToUserMapping = (global as any).stateToUserMapping || new Map();
    (global as any).stateToUserMapping.set(state, userId);

    const params = new URLSearchParams({
      client_id: WHOOP_CONFIG.clientId,
      redirect_uri: WHOOP_CONFIG.redirectUri,
      response_type: 'code',
      scope: WHOOP_CONFIG.scopes.join(' '),
      state: state
    });

    return `${WHOOP_CONFIG.authorizationURL}?${params.toString()}`;
  }

  static async exchangeCodeForTokens(code: string): Promise<{
    access_token: string;
    refresh_token: string;
    expires_in: number;
  }> {
    const response = await fetch(WHOOP_CONFIG.tokenURL, {
      method: 'POST',
      headers: {
        'Content-Type': 'application/x-www-form-urlencoded',
      },
      body: new URLSearchParams({
        grant_type: 'authorization_code',
        code,
        client_id: WHOOP_CONFIG.clientId!,
        client_secret: WHOOP_CONFIG.clientSecret!,
        redirect_uri: WHOOP_CONFIG.redirectUri!
      })
    });

    if (!response.ok) {
      const error = await response.text();
      throw new Error(`WHOOP token exchange failed: ${error}`);
    }

    return response.json();
  }

  static async refreshAccessToken(refreshToken: string): Promise<{
    access_token: string;
    refresh_token: string;
    expires_in: number;
  }> {
    const response = await fetch(WHOOP_CONFIG.tokenURL, {
      method: 'POST',
      headers: {
        'Content-Type': 'application/x-www-form-urlencoded',
      },
      body: new URLSearchParams({
        grant_type: 'refresh_token',
        refresh_token: refreshToken,
        client_id: WHOOP_CONFIG.clientId!,
        client_secret: WHOOP_CONFIG.clientSecret!,
        scope: 'offline'
      })
    });

    if (!response.ok) {
      const error = await response.text();
      throw new Error(`WHOOP token refresh failed: ${error}`);
    }

    return response.json();
  }

  static async getUserProfile(accessToken: string) {
    const response = await fetch(`${WHOOP_CONFIG.baseURL}/user/profile/basic`, {
      headers: {
        'Authorization': `Bearer ${accessToken}`,
        'Content-Type': 'application/json'
      }
    });

    if (!response.ok) {
      throw new Error('Failed to fetch WHOOP user profile');
    }

    return response.json();
  }

  static async getRecoveryData(accessToken: string, limit: number = 7) {
    const response = await fetch(`${WHOOP_CONFIG.baseURL}/recovery?limit=${limit}`, {
      headers: {
        'Authorization': `Bearer ${accessToken}`,
        'Content-Type': 'application/json'
      }
    });

    if (!response.ok) {
      throw new Error('Failed to fetch WHOOP recovery data');
    }

    return response.json();
  }

  static async getSleepData(accessToken: string, limit: number = 7) {
    const response = await fetch(`${WHOOP_CONFIG.baseURL}/activity/sleep?limit=${limit}`, {
      headers: {
        'Authorization': `Bearer ${accessToken}`,
        'Content-Type': 'application/json'
      }
    });

    if (!response.ok) {
      throw new Error('Failed to fetch WHOOP sleep data');
    }

    return response.json();
  }

  static async getCycleData(accessToken: string, limit: number = 7) {
    const response = await fetch(`${WHOOP_CONFIG.baseURL}/cycle?limit=${limit}`, {
      headers: {
        'Authorization': `Bearer ${accessToken}`,
        'Content-Type': 'application/json'
      }
    });

    if (!response.ok) {
      throw new Error('Failed to fetch WHOOP cycle data');
    }

    return response.json();
  }
}

// Terra API Integration for Apple HealthKit
export class AppleHealthIntegration {
  
  static generateAuthURL(userId: number): string {
    if (!TERRA_CONFIG.devId) {
      throw new Error('Terra API credentials not configured');
    }

    // Terra API uses a different flow - generate auth URL for Apple Health
    const params = new URLSearchParams({
      resource: 'APPLE',
      auth_success_redirect_url: `${process.env.BASE_URL}/api/auth/apple/callback`,
      auth_failure_redirect_url: `${process.env.BASE_URL}/api/auth/apple/error`,
      state: `apple_${userId}`
    });

    return `https://widget.tryterra.co/session?${params.toString()}`;
  }

  static async authenticateUser(userId: number, authData: any): Promise<{
    user_id: string;
    provider: string;
    status: string;
  }> {
    const response = await fetch(`${TERRA_CONFIG.baseURL}/auth/authenticateUser`, {
      method: 'POST',
      headers: {
        'dev-id': TERRA_CONFIG.devId!,
        'x-api-key': TERRA_CONFIG.apiKey!,
        'Content-Type': 'application/json'
      },
      body: JSON.stringify(authData)
    });

    if (!response.ok) {
      const error = await response.text();
      throw new Error(`Terra authentication failed: ${error}`);
    }

    return response.json();
  }

  static async getSleep(terraUserId: string, startDate: string, endDate: string) {
    const response = await fetch(
      `${TERRA_CONFIG.baseURL}/sleep?user_id=${terraUserId}&start_date=${startDate}&end_date=${endDate}`,
      {
        headers: {
          'dev-id': TERRA_CONFIG.devId!,
          'x-api-key': TERRA_CONFIG.apiKey!
        }
      }
    );

    if (!response.ok) {
      throw new Error('Failed to fetch Apple Health sleep data');
    }

    return response.json();
  }

  static async getDaily(terraUserId: string, startDate: string, endDate: string) {
    const response = await fetch(
      `${TERRA_CONFIG.baseURL}/daily?user_id=${terraUserId}&start_date=${startDate}&end_date=${endDate}`,
      {
        headers: {
          'dev-id': TERRA_CONFIG.devId!,
          'x-api-key': TERRA_CONFIG.apiKey!
        }
      }
    );

    if (!response.ok) {
      throw new Error('Failed to fetch Apple Health daily data');
    }

    return response.json();
  }

  static async getBody(terraUserId: string, startDate: string, endDate: string) {
    const response = await fetch(
      `${TERRA_CONFIG.baseURL}/body?user_id=${terraUserId}&start_date=${startDate}&end_date=${endDate}`,
      {
        headers: {
          'dev-id': TERRA_CONFIG.devId!,
          'x-api-key': TERRA_CONFIG.apiKey!
        }
      }
    );

    if (!response.ok) {
      throw new Error('Failed to fetch Apple Health body data');
    }

    return response.json();
  }
}

// Data transformation utilities
export class WearableDataTransformer {
  
  static transformWHOOPData(recoveryData: any, sleepData: any, cycleData: any): WearableData {
    const latestRecovery = recoveryData.records?.[0];
    const latestSleep = sleepData.records?.[0];
    const latestCycle = cycleData.records?.[0];

    return {
      sleepScore: latestSleep?.score?.sleep_performance_percentage || null,
      sleepDuration: latestSleep ? this.formatSleepDuration(latestSleep.score?.stage_summary?.total_in_bed_time_milli - latestSleep.score?.stage_summary?.total_awake_time_milli) : '0h 0m',
      strainLevel: latestCycle?.score?.strain,
      hrv: latestRecovery?.score?.hrv_rmssd_milli,
      heartRate: latestRecovery?.score?.resting_heart_rate,
      recoveryScore: latestRecovery?.score?.recovery_score,
      deviceType: 'whoop',
      recordedAt: new Date(latestRecovery?.created_at || Date.now())
    };
  }

  static transformAppleHealthData(sleepData: any, dailyData: any, bodyData: any): WearableData {
    const latestSleep = sleepData.data?.[0];
    const latestDaily = dailyData.data?.[0];
    const latestBody = bodyData.data?.[0];

    return {
      sleepScore: this.calculateSleepScore(latestSleep),
      sleepDuration: latestSleep ? this.formatSleepDuration(latestSleep.duration_asleep_state_milli) : undefined,
      strainLevel: this.calculateStrainLevel(latestDaily),
      hrv: latestDaily?.hrv_data?.avg_hrv_rmssd,
      heartRate: latestDaily?.heart_rate_data?.avg_hr_bpm,
      recoveryScore: this.calculateRecoveryScore(latestSleep, latestDaily),
      deviceType: 'apple_watch',
      recordedAt: new Date(latestDaily?.metadata?.start_time || Date.now())
    };
  }

  private static formatSleepDuration(milliseconds?: number): string {
    if (!milliseconds) return '0h 0m';
    
    const hours = Math.floor(milliseconds / (1000 * 60 * 60));
    const minutes = Math.floor((milliseconds % (1000 * 60 * 60)) / (1000 * 60));
    
    return `${hours}h ${minutes}m`;
  }

  private static calculateSleepScore(sleepData: any): number {
    if (!sleepData) return 70;
    
    // Simple sleep score calculation based on efficiency and duration
    const efficiency = sleepData.sleep_efficiency_percentage || 85;
    const durationHours = (sleepData.duration_asleep_state_milli || 7 * 60 * 60 * 1000) / (1000 * 60 * 60);
    
    let score = efficiency;
    
    // Adjust for sleep duration (7-9 hours is optimal)
    if (durationHours >= 7 && durationHours <= 9) {
      score += 10;
    } else if (durationHours < 6 || durationHours > 10) {
      score -= 15;
    }
    
    return Math.max(0, Math.min(100, Math.round(score)));
  }

  private static calculateStrainLevel(dailyData: any): number {
    if (!dailyData) return 8.5;
    
    // Calculate strain based on active energy and heart rate data
    const activeEnergy = dailyData.calories_data?.total_burned_calories || 2000;
    const avgHeartRate = dailyData.heart_rate_data?.avg_hr_bpm || 70;
    const maxHeartRate = dailyData.heart_rate_data?.max_hr_bpm || 150;
    
    // Simple strain calculation (0-20 scale)
    const energyFactor = Math.min(activeEnergy / 3000, 1) * 10;
    const heartRateFactor = Math.min((maxHeartRate - 60) / 100, 1) * 10;
    
    return Math.round((energyFactor + heartRateFactor) * 10) / 10;
  }

  private static calculateRecoveryScore(sleepData: any, dailyData: any): number {
    if (!sleepData && !dailyData) return 75;
    
    const sleepScore = this.calculateSleepScore(sleepData);
    const hrv = dailyData?.hrv_data?.avg_hrv_rmssd || 40;
    const restingHR = dailyData?.heart_rate_data?.resting_hr_bpm || 60;
    
    // Recovery score based on sleep quality, HRV, and resting heart rate
    let recovery = sleepScore * 0.6; // Sleep is 60% of recovery
    
    // HRV contribution (higher HRV = better recovery)
    recovery += Math.min(hrv / 50, 1) * 25;
    
    // Resting heart rate contribution (lower RHR = better recovery)
    recovery += Math.max(0, (80 - restingHR) / 20) * 15;
    
    return Math.max(0, Math.min(100, Math.round(recovery)));
  }
}