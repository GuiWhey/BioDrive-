import OpenAI from "openai";

// the newest OpenAI model is "gpt-4o" which was released May 13, 2024. do not change this unless explicitly requested by the user
const openai = new OpenAI({ 
  apiKey: process.env.OPENAI_API_KEY || process.env.OPENAI_API_KEY_ENV_VAR || "default_key"
});

export interface MealPlanRequest {
  sleepScore: number;
  strainLevel: number;
  hrv: number;
  subscriptionTier: string;
  mealType: 'breakfast' | 'lunch' | 'dinner';
}

export interface RecoveryProtocolRequest {
  sleepScore: number;
  strainLevel: number;
  hrv: number;
  subscriptionTier: string;
}

export async function generateMealPlan(request: MealPlanRequest): Promise<{
  name: string;
  description: string;
  calories: number;
  protein: number;
  carbs: number;
  fat: number;
  imageUrl: string;
}> {
  try {
    const prompt = `Based on the following biometric data, generate a personalized ${request.mealType} meal plan:
    
    Sleep Score: ${request.sleepScore}/100
    Strain Level: ${request.strainLevel}
    HRV: ${request.hrv}ms
    Subscription Tier: ${request.subscriptionTier}
    
    Generate a meal plan optimized for recovery and performance. Consider:
    - Higher protein for muscle recovery if strain is high
    - More carbs for energy if sleep score is low
    - Anti-inflammatory foods if HRV is low
    - Complex nutrients for premium tiers
    
    Return a JSON object with: name, description, calories, protein (grams), carbs (grams), fat (grams), and suggest an appropriate imageUrl from Unsplash that matches the meal.
    
    Keep the meal realistic and achievable.`;

    const response = await openai.chat.completions.create({
      model: "gpt-4o",
      messages: [
        {
          role: "system",
          content: "You are a certified nutritionist and performance coach. Generate personalized meal plans based on biometric data. Always respond with valid JSON."
        },
        {
          role: "user",
          content: prompt
        }
      ],
      response_format: { type: "json_object" },
      temperature: 0.7,
    });

    const result = JSON.parse(response.choices[0].message.content || '{}');
    
    return {
      name: result.name || `Optimized ${request.mealType}`,
      description: result.description || "A nutritious meal designed for your current recovery state",
      calories: result.calories || 400,
      protein: result.protein || 20,
      carbs: result.carbs || 40,
      fat: result.fat || 15,
      imageUrl: result.imageUrl || "https://images.unsplash.com/photo-1490645935967-10de6ba17061?w=800&h=400&fit=crop"
    };
  } catch (error) {
    console.error('Error generating meal plan:', error);
    throw new Error('Failed to generate meal plan');
  }
}

export async function generateRecoveryProtocol(request: RecoveryProtocolRequest): Promise<{
  coldTherapy: string;
  breathwork: string;
  supplements: string;
}> {
  try {
    const prompt = `Based on the following biometric data, generate personalized recovery protocols:
    
    Sleep Score: ${request.sleepScore}/100
    Strain Level: ${request.strainLevel}
    HRV: ${request.hrv}ms
    Subscription Tier: ${request.subscriptionTier}
    
    Generate specific recovery recommendations for:
    1. Cold therapy (duration and temperature)
    2. Breathwork technique and duration
    3. Supplement recommendations
    
    Consider:
    - More aggressive recovery if strain is high
    - Gentle approaches if HRV is low
    - Premium protocols for higher subscription tiers
    
    Return a JSON object with: coldTherapy, breathwork, supplements (each as a string with specific instructions).`;

    const response = await openai.chat.completions.create({
      model: "gpt-4o",
      messages: [
        {
          role: "system",
          content: "You are a recovery specialist and sports scientist. Generate personalized recovery protocols based on biometric data. Always respond with valid JSON."
        },
        {
          role: "user",
          content: prompt
        }
      ],
      response_format: { type: "json_object" },
      temperature: 0.7,
    });

    const result = JSON.parse(response.choices[0].message.content || '{}');
    
    return {
      coldTherapy: result.coldTherapy || "Cold shower: 2-3 minutes at 15°C",
      breathwork: result.breathwork || "4-7-8 breathing technique for 10 minutes",
      supplements: result.supplements || "Magnesium: 400mg before bed"
    };
  } catch (error) {
    console.error('Error generating recovery protocol:', error);
    throw new Error('Failed to generate recovery protocol');
  }
}

export async function calculatePerformanceScore(
  sleepScore: number,
  recoveryScore: number,
  strainLevel: number
): Promise<number> {
  try {
    const prompt = `Calculate a performance score (0-100) based on:
    Sleep Score: ${sleepScore}/100
    Recovery Score: ${recoveryScore}/100
    Strain Level: ${strainLevel}
    
    Use the formula: (Sleep Score × 0.4) + (Recovery Score × 0.4) + (Strain Level optimization × 0.2)
    
    Where strain level optimization considers:
    - Strain 8-12: Optimal (100 points)
    - Strain 6-8 or 12-15: Good (80 points)
    - Strain < 6 or > 15: Needs adjustment (60 points)
    
    Return a JSON object with: score (integer 0-100)`;

    const response = await openai.chat.completions.create({
      model: "gpt-4o",
      messages: [
        {
          role: "system",
          content: "You are a performance analyst. Calculate performance scores based on biometric data. Always respond with valid JSON."
        },
        {
          role: "user",
          content: prompt
        }
      ],
      response_format: { type: "json_object" },
      temperature: 0.3,
    });

    const result = JSON.parse(response.choices[0].message.content || '{}');
    return Math.max(0, Math.min(100, result.score || 70));
  } catch (error) {
    console.error('Error calculating performance score:', error);
    return 70; // Default score
  }
}

export interface AICoachingRequest {
  userId: number;
  sleepScore: number;
  recoveryScore: number;
  strainLevel: number;
  hrv: number;
  heartRate: number;
  subscriptionTier: string;
  recentPerformanceScores: number[];
  goals?: string[];
  currentChallenges?: string[];
  userPreferences?: {
    workoutTypes?: string[];
    dietaryRestrictions?: string[];
    sleepSchedule?: string;
  };
}

export interface AICoachingResponse {
  personalizedMessage: string;
  keyInsights: string[];
  actionableRecommendations: {
    priority: 'high' | 'medium' | 'low';
    category: 'sleep' | 'recovery' | 'nutrition' | 'training' | 'stress';
    title: string;
    description: string;
    timeframe: string;
  }[];
  weeklyFocus: string;
  motivationalNote: string;
  nextCheckIn: string;
}

export async function generatePersonalizedCoaching(request: AICoachingRequest): Promise<AICoachingResponse> {
  try {
    const performanceTrend = request.recentPerformanceScores.length > 1 
      ? request.recentPerformanceScores[request.recentPerformanceScores.length - 1] - request.recentPerformanceScores[0]
      : 0;

    const response = await openai.chat.completions.create({
      model: "gpt-4o", // the newest OpenAI model is "gpt-4o" which was released May 13, 2024. do not change this unless explicitly requested by the user
      messages: [
        {
          role: "system",
          content: `You are an expert AI health coach specializing in biometric optimization. Provide personalized 1:1 coaching based on comprehensive biometric data.

Your role:
- Analyze patterns in sleep, recovery, strain, and HRV data
- Provide specific, actionable recommendations
- Offer motivational support and accountability
- Tailor advice to subscription tier and user preferences

Guidelines:
- Be conversational and supportive, like a personal coach
- Focus on sustainable improvements, not quick fixes
- Prioritize recommendations based on biggest impact potential
- Reference specific metrics to show you're analyzing their data
- Provide timeframes for when to expect results

User subscription tier: ${request.subscriptionTier}
- Basic: General recommendations, weekly check-ins
- Pro: Detailed analysis, specific protocols, bi-weekly check-ins  
- Elite: Advanced insights, personalized protocols, daily check-ins

Return a JSON response with personalized coaching insights.`
        },
        {
          role: "user",
          content: `Analyze my biometric data and provide personalized coaching:

Current Metrics:
- Sleep Score: ${request.sleepScore}/100
- Recovery Score: ${request.recoveryScore}/100  
- Strain Level: ${request.strainLevel}
- HRV: ${request.hrv}ms
- Heart Rate: ${request.heartRate}bpm

Performance Trend: ${performanceTrend > 0 ? `+${performanceTrend}` : performanceTrend} points over recent sessions

Goals: ${request.goals?.join(', ') || 'General health optimization'}
Current Challenges: ${request.currentChallenges?.join(', ') || 'None specified'}

User Preferences:
- Workout Types: ${request.userPreferences?.workoutTypes?.join(', ') || 'Not specified'}
- Dietary Restrictions: ${request.userPreferences?.dietaryRestrictions?.join(', ') || 'None'}
- Sleep Schedule: ${request.userPreferences?.sleepSchedule || 'Not specified'}

Provide coaching in this JSON format:
{
  "personalizedMessage": "Direct message to user as their coach",
  "keyInsights": ["3-4 specific insights about their data patterns"],
  "actionableRecommendations": [
    {
      "priority": "high|medium|low",
      "category": "sleep|recovery|nutrition|training|stress", 
      "title": "Specific recommendation title",
      "description": "Detailed actionable steps",
      "timeframe": "When to expect results"
    }
  ],
  "weeklyFocus": "Main area to focus on this week",
  "motivationalNote": "Encouraging message based on their progress",
  "nextCheckIn": "When to check progress next"
}`
        }
      ],
      response_format: { type: "json_object" },
      temperature: 0.7,
    });

    const result = JSON.parse(response.choices[0].message.content || '{}');
    
    return {
      personalizedMessage: result.personalizedMessage || "Great work tracking your biometrics! Let's optimize your performance together.",
      keyInsights: result.keyInsights || ["Your data shows interesting patterns we can work with."],
      actionableRecommendations: result.actionableRecommendations || [],
      weeklyFocus: result.weeklyFocus || "Focus on consistent sleep and recovery patterns",
      motivationalNote: result.motivationalNote || "Small consistent improvements lead to breakthrough results.",
      nextCheckIn: result.nextCheckIn || "3 days"
    };
    
  } catch (error) {
    console.error("Error generating personalized coaching:", error);
    throw new Error("Failed to generate personalized coaching recommendations");
  }
}
